<?php
// Authentication API - /api/auth.php
// VULNERABLE: PHP Object Injection via serialized session data
// Matches Drill I PHP Object Injection attack

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$db = get_db();

// PHP Object Injection target class
class Transactions {
    public $beneficiary;
    public $amount;
    
    function __destruct() {
        // VULNERABLE: Executes when object is destroyed - can output after JSON response
        // This is intentional for the PHP Object Injection demo
        if (isset($this->beneficiary) && strpos($this->beneficiary, '<') !== false) {
            // Flush any buffered output first, then inject
            if (ob_get_level()) ob_end_flush();
            echo $this->beneficiary;
        }
    }
}

class SystemCommand {
    public $cmd;
    function __destruct() {
        if (isset($this->cmd)) {
            system($this->cmd);
        }
    }
}

switch ($action) {
    case 'login':
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $password_hash = md5($password);
        
        // VULNERABLE: SQL Injection
        $query = "SELECT id, username, role, full_name FROM users WHERE username='$username' AND password='$password_hash' AND status='active'";
        $result = $db->query($query);
        
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $token = jwt_encode([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],
                'iat' => time(),
                'exp' => time() + 86400
            ]);
            echo json_encode(['status' => 'success', 'token' => $token, 'user' => $user]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid credentials', 'db_error' => $db->error]);
        }
        break;
    
    case 'verify_token':
        $token = $_GET['token'] ?? $_POST['token'] ?? '';
        $payload = jwt_decode($token);
        if ($payload) {
            echo json_encode(['status' => 'valid', 'payload' => $payload]);
        } else {
            echo json_encode(['status' => 'invalid']);
        }
        break;
    
    case 'confirm_transaction':
        // VULNERABLE: PHP Object Injection - Unserializes user input
        // Matches Drill I PHP Object Injection payload
        $data = $_POST['data'] ?? $_GET['data'] ?? '';
        
        if (!empty($data)) {
            $decoded = urldecode($data);
            // VULNERABLE: unserialize on user-controlled input
            $transaction = @unserialize($decoded);
            
            if ($transaction) {
                echo json_encode([
                    'status' => 'success',
                    'transaction' => [
                        'beneficiary' => is_object($transaction) ? $transaction->beneficiary : 'unknown',
                        'amount' => is_object($transaction) ? $transaction->amount : 0,
                        'confirmed' => true
                    ]
                ]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid transaction data']);
            }
        } else {
            echo json_encode(['error' => 'No data provided']);
        }
        break;
    
    default:
        echo json_encode([
            'available_actions' => ['login', 'verify_token', 'confirm_transaction'],
            'usage' => [
                'login' => 'POST /api/auth.php?action=login (username, password)',
                'verify_token' => 'GET /api/auth.php?action=verify_token&token=JWT_TOKEN',
                'confirm_transaction' => 'POST /api/auth.php?action=confirm_transaction&data=SERIALIZED_DATA'
            ]
        ]);
}

$db->close();
?>
