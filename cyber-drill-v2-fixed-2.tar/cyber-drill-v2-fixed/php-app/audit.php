<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$logs = $db->query("SELECT * FROM audit_logs ORDER BY timestamp DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header"><h2>Audit Logs</h2><p>Complete system activity trail</p></div>
            <div class="content-card">
                <div class="card-header"><h3>Activity Log</h3></div>
                <table class="data-table">
                    <thead><tr><th>Timestamp</th><th>User</th><th>Action</th><th>Details</th><th>IP Address</th><th>User Agent</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php while($log = $logs->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('d-M-Y H:i:s', strtotime($log['timestamp'])); ?></td>
                        <td><code><?php echo $log['user']; ?></code></td>
                        <td><code><?php echo $log['action']; ?></code></td>
                        <td><?php echo $log['details']; ?></td>
                        <td><code><?php echo $log['ip_address']; ?></code></td>
                        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;"><?php echo htmlspecialchars($log['user_agent']); ?></td>
                        <td><span class="badge badge-<?php echo $log['status']; ?>"><?php echo $log['status']; ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
<?php $db->close(); ?>
