<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager' && $_SESSION['role'] !== 'cashier') { header('Location: dashboard.php'); exit; }
$db = get_db();
$users = $db->query("SELECT * FROM users ORDER BY id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header"><h2>User Management</h2><p>Manage employee and customer accounts</p></div>
            <div class="content-card">
                <div class="card-header">
                    <h3>All Users</h3>
                    <button onclick="fetchUsersAPI()" class="btn-primary" style="padding:8px 16px;font-size:12px;">Fetch via API</button>
                </div>
                <div id="apiUserResult" style="display:none;padding:10px 20px;"></div>
                <table class="data-table">
                    <thead><tr><th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Role</th><th>Employee ID</th><th>Branch</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php while($u = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $u['id']; ?></td>
                        <td><code><?php echo $u['username']; ?></code></td>
                        <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                        <td><?php echo $u['email']; ?></td>
                        <td><span class="badge badge-<?php echo $u['role']==='admin'?'warning':'success'; ?>"><?php echo ucfirst($u['role']); ?></span></td>
                        <td><?php echo $u['employee_id'] ?: '-'; ?></td>
                        <td><?php echo $u['branch_code']; ?></td>
                        <td><span class="badge badge-<?php echo $u['status']; ?>"><?php echo ucfirst($u['status']); ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
    <script>
    function fetchUsersAPI() {
        fetch('/api/internal.php?action=get_all_users')
            .then(r => r.json())
            .then(d => {
                var el = document.getElementById('apiUserResult');
                el.style.display = 'block';
                el.innerHTML = '<pre style="background:#f0f2f5;padding:10px;border-radius:6px;font-size:11px;max-height:300px;overflow:auto;">' + JSON.stringify(d, null, 2) + '</pre>';
            });
    }
    </script>
</body>
</html>
<?php $db->close(); ?>
