#!/bin/bash
# Wait for MySQL to be ready before starting Apache
# Tries both root (no pass) and bankadmin credentials during first-boot window
MAX_WAIT=60
for i in $(seq 1 $MAX_WAIT); do
    # Try bankadmin TCP connection (post-init state)
    if mysqladmin -u bankadmin -p'B@nkAdm1n_2024' -h 127.0.0.1 ping --silent 2>/dev/null; then
        echo "[start-apache] MySQL ready (bankadmin)"
        break
    fi
    # Try socket as root (skip-grant-tables init window)
    if mysqladmin ping --silent 2>/dev/null; then
        echo "[start-apache] MySQL ready (root socket)"
        break
    fi
    # After 45s give up waiting and start Apache anyway (PHP will show DB error when accessed)
    if [ "$i" -ge 45 ]; then
        echo "[start-apache] MySQL not ready after ${i}s — starting Apache anyway"
        break
    fi
    sleep 1
done
echo "[start-apache] Starting Apache2"
source /etc/apache2/envvars
exec /usr/sbin/apache2 -D FOREGROUND
