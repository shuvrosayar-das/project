<?php
// API Endpoint: /api/accounts.php
// VULNERABLE: SQL Injection via acc_no parameter (matching Drill I & IV)
// URL pattern: /api/accounts.php?api=get_user&acc_no=<INJECTABLE>

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$api_action = $_GET['api'] ?? $_POST['api'] ?? '';
$db = get_db();

switch ($api_action) {
    case 'get_user':
        // VULNERABLE: Direct parameter concatenation - SQL Injection
        // Matches: /ubibank/account/admin.php?api=get_user&acc_no=
        $acc_no = $_GET['acc_no'] ?? '';
        
        if (empty($acc_no)) {
            echo json_encode(['error' => 'Account number required']);
            break;
        }
        
        // VULNERABLE: No parameterized query, error-based injection possible
        $query = "SELECT a.*, u.full_name, u.email, u.phone, u.pan_number 
                  FROM accounts a 
                  LEFT JOIN users u ON a.user_id = u.id 
                  WHERE a.id = $acc_no OR a.account_number = '$acc_no'";
        
        $result = $db->query($query);
        
        if ($result === false) {
            // VULNERABLE: MySQL error disclosure (error-based SQLi feedback)
            echo json_encode([
                'error' => 'Query failed',
                'message' => $db->error,
                'query_debug' => $query
            ]);
        } elseif ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode(['status' => 'success', 'data' => $data]);
        } else {
            echo json_encode(['status' => 'success', 'data' => [], 'message' => 'No records found']);
        }
        break;
    
    case 'get_transactions':
        $acc_no = $_GET['acc_no'] ?? '';
        // VULNERABLE: SQL Injection
        $query = "SELECT * FROM transactions WHERE from_account='$acc_no' OR to_account='$acc_no' ORDER BY transaction_date DESC";
        $result = $db->query($query);
        if ($result === false) {
            echo json_encode(['error' => $db->error]);
        } else {
            $data = [];
            while ($row = $result->fetch_assoc()) $data[] = $row;
            echo json_encode(['status' => 'success', 'data' => $data]);
        }
        break;
    
    case 'beneficiary_transactions':
        // VULNERABLE: Second-Order SQL Injection
        // Step 1: Nickname was stored safely via prepared statement in transfers.php
        // Step 2: Nickname is fetched from DB and used UNSAFELY in a second query
        // Attack: Store malicious SQL as nickname, then trigger this endpoint
        $ben_id = $_GET['ben_id'] ?? '';
        
        if (!empty($ben_id)) {
            // Safe fetch of beneficiary record
            $stmt = $db->prepare("SELECT * FROM beneficiaries WHERE id = ?");
            $stmt->bind_param("i", $ben_id);
            $stmt->execute();
            $ben_result = $stmt->get_result();
            
            if ($ben_result->num_rows > 0) {
                $beneficiary = $ben_result->fetch_assoc();
                $nickname = $beneficiary['nickname'];
                
                // VULNERABLE: Second-order injection - nickname from DB used directly in query
                // If nickname contains SQL payload like: ' UNION SELECT * FROM users -- 
                // it will execute here
                $txn_query = "SELECT t.*, '$nickname' as beneficiary_label 
                              FROM transactions t 
                              WHERE t.to_account = '{$beneficiary['account_number']}' 
                              OR t.description LIKE '%$nickname%' 
                              ORDER BY t.transaction_date DESC";
                
                $txn_result = $db->query($txn_query);
                if ($txn_result === false) {
                    echo json_encode([
                        'error' => 'Query failed',
                        'message' => $db->error,
                        'debug_query' => $txn_query
                    ]);
                } else {
                    $txns = [];
                    while ($row = $txn_result->fetch_assoc()) $txns[] = $row;
                    echo json_encode([
                        'status' => 'success',
                        'beneficiary' => $beneficiary,
                        'transactions' => $txns
                    ]);
                }
            } else {
                echo json_encode(['error' => 'Beneficiary not found']);
            }
        } else {
            echo json_encode(['error' => 'ben_id required']);
        }
        break;
    
    case 'get_all_accounts':
        // VULNERABLE: No authentication check for sensitive data
        $result = $db->query("SELECT * FROM accounts");
        $data = [];
        while ($row = $result->fetch_assoc()) $data[] = $row;
        echo json_encode(['status' => 'success', 'count' => count($data), 'data' => $data]);
        break;
    
    case 'search':
        $term = $_GET['q'] ?? '';
        // VULNERABLE: SQL Injection in search
        $query = "SELECT * FROM accounts WHERE account_holder LIKE '%$term%' OR account_number LIKE '%$term%'";
        $result = $db->query($query);
        if ($result === false) {
            echo json_encode(['error' => $db->error]);
        } else {
            $data = [];
            while ($row = $result->fetch_assoc()) $data[] = $row;
            echo json_encode(['status' => 'success', 'data' => $data]);
        }
        break;
    
    case 'render_account':
        // VULNERABLE: Reflected XSS - outputs acc_no directly in HTML response
        // This endpoint renders account details as an HTML page (for print/export)
        header('Content-Type: text/html; charset=UTF-8');
        $acc_no = $_GET['acc_no'] ?? '';
        
        echo "<!DOCTYPE html><html><head><title>Account Details</title>";
        echo "<style>body{font-family:sans-serif;padding:20px;} table{border-collapse:collapse;width:100%;} ";
        echo "th,td{border:1px solid #ddd;padding:8px;text-align:left;} th{background:#003580;color:white;}</style></head><body>";
        echo "<h2>Account Details - Search: " . $acc_no . "</h2>"; // VULNERABLE: Direct output, no escaping
        
        if (!empty($acc_no)) {
            // VULNERABLE: SQL Injection + XSS combined
            $query = "SELECT a.*, u.full_name, u.email FROM accounts a LEFT JOIN users u ON a.user_id = u.id WHERE a.id = $acc_no OR a.account_number = '$acc_no'";
            $result = $db->query($query);
            
            if ($result === false) {
                echo "<div style='color:red;'><strong>Error:</strong> " . $db->error . "</div>";
                echo "<pre>Query: " . $query . "</pre>";
            } elseif ($result->num_rows > 0) {
                echo "<table><thead><tr><th>Account #</th><th>Holder</th><th>Type</th><th>Balance</th><th>Branch</th><th>IFSC</th><th>Status</th></tr></thead><tbody>";
                while ($row = $result->fetch_assoc()) {
                    // VULNERABLE: No escaping in HTML output
                    echo "<tr><td>{$row['account_number']}</td><td>{$row['account_holder']}</td><td>{$row['account_type']}</td>";
                    echo "<td>₹" . number_format($row['balance'], 2) . "</td><td>{$row['branch_code']}</td><td>{$row['ifsc_code']}</td><td>{$row['status']}</td></tr>";
                }
                echo "</tbody></table>";
            } else {
                echo "<p>No accounts found matching: " . $acc_no . "</p>"; // VULNERABLE: Reflected XSS
            }
        } else {
            echo "<p>Please provide an account number (acc_no parameter)</p>";
        }
        echo "</body></html>";
        exit;
    
    default:
        echo json_encode([
            'error' => 'Invalid API action',
            'available_actions' => ['get_user', 'get_transactions', 'beneficiary_transactions', 'get_all_accounts', 'search', 'render_account'],
            'usage' => '/api/accounts.php?api=get_user&acc_no=1',
            'server_info' => [
                'php_version' => phpversion(),
                'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
            ]
        ]);
}

$db->close();
?>
