<?php if(!isset($_SESSION['user_id'])){header('Location: index.php');exit;} ?>
<div class="top-bar">
    <div class="toll-free">
        <span>&#9742;</span> IT Helpdesk: <span>Ext. 4400</span> | Email: <span>ithelpdesk@unionbank.internal</span>
    </div>
    <div>
        Logged in: <strong><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></strong> 
        (<?php echo ucfirst($_SESSION['role']); ?>) | 
        <a href="logout.php" style="color:#ffffff;">Logout</a>
    </div>
</div>
<div class="header">
    <div class="logo-section">
        <img src="images/ubi-logo.svg" alt="UBI" style="width:48px;height:48px;border-radius:8px;">
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p>Internal Banking Operations Portal</p>
        </div>
    </div>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>
