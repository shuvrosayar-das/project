<?php
/*
Plugin Name: Developer Flavor Hash Form
Plugin URI: https://developer-flavor.com
Description: Advanced form builder plugin
Version: 1.1.0
Author: Developer Flavor
*/

// CVE-2024-5084: Missing file type validation in upload handler
add_action('wp_ajax_hashform_file_upload_action', 'hashform_file_upload');
add_action('wp_ajax_nopriv_hashform_file_upload_action', 'hashform_file_upload');

function hashform_file_upload() {
    // VULNERABLE: No file type validation
    $nonce = isset($_GET['file_uploader_nonce']) ? sanitize_text_field($_GET['file_uploader_nonce']) : '';

    // Weak nonce verification (intentional)
    if (empty($nonce)) {
        // Still allows upload even without valid nonce
    }

    $allowed = isset($_GET['allowedExtensions']) ? $_GET['allowedExtensions'] : array();
    $file_name = isset($_GET['qqfile']) ? $_GET['qqfile'] : '';

    if (empty($file_name)) {
        wp_send_json_error('No file specified');
        return;
    }

    $upload_dir = wp_upload_dir();
    $target_dir = $upload_dir['basedir'] . '/hashform_uploads/';

    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . basename($file_name);

    // VULNERABLE: File is accepted regardless of extension
    // No magic byte verification
    // No file type whitelist enforcement
    $input = fopen('php://input', 'r');
    $output = fopen($target_file, 'w');

    if ($input && $output) {
        while ($data = fread($input, 8192)) {
            fwrite($output, $data);
        }
        fclose($input);
        fclose($output);
        chmod($target_file, 0755);

        wp_send_json_success(array(
            'success' => true,
            'file_url' => $upload_dir['baseurl'] . '/hashform_uploads/' . basename($file_name)
        ));
    } else {
        wp_send_json_error('Upload failed');
    }
}
?>
