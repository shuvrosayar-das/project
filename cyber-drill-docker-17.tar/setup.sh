#!/bin/bash
###############################################################################
# Union Bank of India - Cyber Drill VM Setup Script
# One-click deployment on Ubuntu 22.04 LTS (bare metal / VM)
#
# Usage: sudo bash setup.sh
#
# This script installs and configures ALL components:
#   - Apache 2.4 + PHP 8.1 (mod_php for main portal, php-cgi for CVE-2024-4577)
#   - MySQL 8.0 (intentionally weak config)
#   - Tomcat 9.0.65 + Log4j 2.14.1 (CVE-2021-44228)
#   - OpenSSH (weak config)
#   - WordPress + vulnerable plugin
#   - Cron jobs, SUID binaries, privilege escalation paths
#   - All 15 attack vectors pre-configured
###############################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# Sanity checks
[[ $EUID -ne 0 ]] && err "Run as root: sudo bash setup.sh"
[[ ! -f /etc/lsb-release ]] && err "Ubuntu required"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="/opt/lampp/htdocs/bankportal"
CGI_DIR="/var/www/cgi-portal"
TOMCAT_DIR="/opt/tomcat"
TOMCAT_VER="9.0.65"
LOG4J_VER="2.14.1"
MYSQL_ROOT_PASS="R00t_MySQL_2024!"
MYSQL_APP_USER="bankadmin"
MYSQL_APP_PASS="B@nkAdm1n_2024"

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   Union Bank of India - Cyber Drill VM Setup                ║"
echo "║   ⚠  INTENTIONALLY VULNERABLE - Isolated networks only     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

###############################################################################
# 1. System packages
###############################################################################
log "Installing system packages..."
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq

# Pre-seed MySQL root password
echo "mysql-server mysql-server/root_password password ${MYSQL_ROOT_PASS}" | debconf-set-selections
echo "mysql-server mysql-server/root_password_again password ${MYSQL_ROOT_PASS}" | debconf-set-selections

apt-get install -y -qq \
    apache2 libapache2-mod-php8.1 \
    php8.1 php8.1-mysql php8.1-xml php8.1-mbstring php8.1-curl \
    php8.1-zip php8.1-gd php8.1-intl php8.1-soap php8.1-bcmath \
    php8.1-cli php8.1-cgi \
    mysql-server mysql-client \
    default-jdk \
    openssh-server \
    cron at sudo vim nano \
    python3 python3-pip \
    unzip wget curl net-tools build-essential \
    2>/dev/null

a2enmod rewrite headers proxy proxy_http php8.1 actions cgi 2>/dev/null

log "Packages installed"

###############################################################################
# 2. PHP config (intentionally insecure)
###############################################################################
log "Configuring PHP (insecure)..."
for INI in /etc/php/8.1/apache2/php.ini /etc/php/8.1/cgi/php.ini; do
    [ ! -f "$INI" ] && continue
    sed -i 's/display_errors = Off/display_errors = On/' "$INI"
    sed -i 's/display_startup_errors = Off/display_startup_errors = On/' "$INI"
    sed -i 's/expose_php = Off/expose_php = On/' "$INI"
    sed -i 's/;allow_url_include = Off/allow_url_include = On/' "$INI"
    sed -i 's/allow_url_include = Off/allow_url_include = On/' "$INI"
    sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 50M/' "$INI"
    sed -i 's/post_max_size = 8M/post_max_size = 50M/' "$INI"
    sed -i 's/^disable_functions = .*/disable_functions = /' "$INI"
    sed -i 's/session.cookie_httponly = 1/session.cookie_httponly = 0/' "$INI"
done

# CGI-specific insecure settings
CGI_INI=/etc/php/8.1/cgi/php.ini
if [ -f "$CGI_INI" ]; then
    sed -i 's/;cgi.force_redirect = 1/cgi.force_redirect = 0/' "$CGI_INI"
    sed -i 's/cgi.force_redirect = 1/cgi.force_redirect = 0/' "$CGI_INI"
    grep -q "register_argc_argv = On" "$CGI_INI" || echo "register_argc_argv = On" >> "$CGI_INI"
fi

mkdir -p /var/lib/php/sessions && chmod 1733 /var/lib/php/sessions

###############################################################################
# 3. MySQL setup
###############################################################################
log "Configuring MySQL..."
systemctl start mysql 2>/dev/null || service mysql start

# Weaken MySQL config
MYSQL_CNF="/etc/mysql/mysql.conf.d/mysqld.cnf"
if [ -f "$MYSQL_CNF" ]; then
    sed -i 's/bind-address\s*=\s*127.0.0.1/bind-address = 0.0.0.0/' "$MYSQL_CNF" 2>/dev/null
    grep -q "local-infile" "$MYSQL_CNF" || echo "local-infile=1" >> "$MYSQL_CNF"
    grep -q "secure-file-priv" "$MYSQL_CNF" || echo 'secure-file-priv=""' >> "$MYSQL_CNF"
fi

systemctl restart mysql 2>/dev/null || service mysql restart
sleep 2

# Create databases and users
mysql -u root -p"${MYSQL_ROOT_PASS}" <<SQLSETUP 2>/dev/null || mysql -u root <<SQLSETUP
CREATE DATABASE IF NOT EXISTS bankportal_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS wordpress_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
DROP USER IF EXISTS '${MYSQL_APP_USER}'@'localhost';
DROP USER IF EXISTS '${MYSQL_APP_USER}'@'%';
DROP USER IF EXISTS '${MYSQL_APP_USER}'@'127.0.0.1';
CREATE USER '${MYSQL_APP_USER}'@'localhost' IDENTIFIED BY '${MYSQL_APP_PASS}';
CREATE USER '${MYSQL_APP_USER}'@'%' IDENTIFIED BY '${MYSQL_APP_PASS}';
CREATE USER '${MYSQL_APP_USER}'@'127.0.0.1' IDENTIFIED BY '${MYSQL_APP_PASS}';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'localhost';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'%';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'127.0.0.1';
GRANT ALL PRIVILEGES ON wordpress_db.* TO '${MYSQL_APP_USER}'@'localhost';
GRANT ALL PRIVILEGES ON wordpress_db.* TO '${MYSQL_APP_USER}'@'%';
GRANT ALL PRIVILEGES ON wordpress_db.* TO '${MYSQL_APP_USER}'@'127.0.0.1';
GRANT FILE ON *.* TO '${MYSQL_APP_USER}'@'localhost';
FLUSH PRIVILEGES;
SQLSETUP

# Import banking data
if [ -f "${SCRIPT_DIR}/db/init.sql" ]; then
    mysql -u root -p"${MYSQL_ROOT_PASS}" bankportal_db < "${SCRIPT_DIR}/db/init.sql" 2>/dev/null || \
    mysql -u root bankportal_db < "${SCRIPT_DIR}/db/init.sql"
    log "Banking data imported"
fi

###############################################################################
# 4. Deploy PHP Banking Portal (port 80)
###############################################################################
log "Deploying banking portal..."
mkdir -p "${APP_DIR}"/{uploads,backup,templates,images,.ssh}
cp -r "${SCRIPT_DIR}/php-app/"* "${APP_DIR}/"
chown -R www-data:www-data "${APP_DIR}"
chmod -R 755 "${APP_DIR}"
chmod 777 "${APP_DIR}/uploads" "${APP_DIR}/templates" "${APP_DIR}/images"
chmod 666 "${APP_DIR}/index.php"

# Upload .htaccess for PHP execution in uploads
echo 'AddHandler application/x-httpd-php .php .phtml .php5 .php7 .pht' > "${APP_DIR}/uploads/.htaccess"
echo 'Options +ExecCGI' >> "${APP_DIR}/uploads/.htaccess"

# Sensitive files
cat > "${APP_DIR}/.env" <<'ENVFILE'
APP_ENV=production
APP_DEBUG=true
APP_KEY=base64:weak_application_key_2024
DB_HOST=localhost
DB_DATABASE=bankportal_db
DB_USERNAME=bankadmin
DB_PASSWORD=B@nkAdm1n_2024
MYSQL_ROOT_PASSWORD=R00t_MySQL_2024!
JWT_SECRET=BankPortal_JWT_Weak_Secret_2024
API_KEY=ak_live_bp2024_x9f2k3m5n7p1q4r6
ENVFILE

cat > "${APP_DIR}/.htaccess" <<'HTACCESS'
Options +Indexes +FollowSymLinks +ExecCGI
RewriteEngine On
Header unset X-Frame-Options
Header unset X-Content-Type-Options
Header unset X-XSS-Protection
HTACCESS

# Apache vhost for banking portal
cat > /etc/apache2/sites-available/bankportal.conf <<'VHOST'
<VirtualHost *:80>
    ServerName bankportal.local
    DocumentRoot /opt/lampp/htdocs/bankportal
    <Directory /opt/lampp/htdocs/bankportal>
        Options Indexes FollowSymLinks MultiViews
        AllowOverride All
        Require all granted
    </Directory>
    ProxyPass /bankingapp http://localhost:8080/bankingapp
    ProxyPassReverse /bankingapp http://localhost:8080/bankingapp
    ErrorDocument 404 /error.php
    ErrorDocument 500 /error.php
    Header unset X-Frame-Options
    Header unset X-Content-Type-Options
    Header unset X-XSS-Protection
    Header unset Content-Security-Policy
    Header unset Strict-Transport-Security
    LogLevel debug
    ErrorLog /var/log/apache2/bankportal-error.log
    CustomLog /var/log/apache2/bankportal-access.log combined
</VirtualHost>
VHOST

cat > /etc/apache2/conf-available/allow-uploads.conf <<'UPCONF'
<Directory "/opt/lampp/htdocs/bankportal/uploads">
    Options +ExecCGI
    AddHandler application/x-httpd-php .php .phtml .php5
    Require all granted
</Directory>
UPCONF

a2dissite 000-default.conf 2>/dev/null
a2ensite bankportal.conf 2>/dev/null
a2enconf allow-uploads 2>/dev/null

# Server tokens (verbose)
sed -i 's/ServerTokens OS/ServerTokens Full/' /etc/apache2/conf-enabled/security.conf 2>/dev/null
sed -i 's/ServerTokens Prod/ServerTokens Full/' /etc/apache2/conf-enabled/security.conf 2>/dev/null
sed -i 's/ServerSignature Off/ServerSignature On/' /etc/apache2/conf-enabled/security.conf 2>/dev/null

###############################################################################
# 5. Deploy CVE-2024-4577 CGI Portal (port 8888)
###############################################################################
log "Deploying Customer Support Portal (CVE-2024-4577)..."
mkdir -p "${CGI_DIR}"
cp -r "${SCRIPT_DIR}/cgi-app/"* "${CGI_DIR}/"
cp "${SCRIPT_DIR}/cgi-bin-wrapper.sh" /usr/lib/cgi-bin/php-cgi-wrapper.sh
chmod +x /usr/lib/cgi-bin/php-cgi-wrapper.sh
chown -R www-data:www-data "${CGI_DIR}"

# Add Listen 8888
grep -q "Listen 8888" /etc/apache2/ports.conf || echo "Listen 8888" >> /etc/apache2/ports.conf

cat > /etc/apache2/sites-available/cgi-portal.conf <<'CGIVHOST'
<VirtualHost *:8888>
    ServerName support.unionbank.internal
    DocumentRoot /var/www/cgi-portal
    ScriptAlias /cgi-bin/ /usr/lib/cgi-bin/
    Action php-cgi /cgi-bin/php-cgi-wrapper.sh
    AddHandler php-cgi .php
    <Directory /var/www/cgi-portal>
        Options +ExecCGI +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    <Directory /usr/lib/cgi-bin>
        Options +ExecCGI
        Require all granted
    </Directory>
    Header unset X-Frame-Options
    Header unset Content-Security-Policy
    ServerSignature On
    ErrorLog /var/log/apache2/cgi-portal-error.log
    CustomLog /var/log/apache2/cgi-portal-access.log combined
</VirtualHost>
CGIVHOST

a2ensite cgi-portal.conf 2>/dev/null

###############################################################################
# 6. Tomcat 9.0.65 + Log4j 2.14.1
###############################################################################
log "Installing Tomcat ${TOMCAT_VER} + Log4j ${LOG4J_VER}..."
mkdir -p "${TOMCAT_DIR}"

wget -q "https://archive.apache.org/dist/tomcat/tomcat-9/v${TOMCAT_VER}/bin/apache-tomcat-${TOMCAT_VER}.tar.gz" \
     -O /tmp/tomcat.tar.gz
tar -xzf /tmp/tomcat.tar.gz -C "${TOMCAT_DIR}" --strip-components=1
rm -f /tmp/tomcat.tar.gz

wget -q "https://archive.apache.org/dist/logging/log4j/${LOG4J_VER}/apache-log4j-${LOG4J_VER}-bin.tar.gz" \
     -O /tmp/log4j.tar.gz
tar -xzf /tmp/log4j.tar.gz -C /tmp/
cp /tmp/apache-log4j-${LOG4J_VER}-bin/log4j-core-${LOG4J_VER}.jar "${TOMCAT_DIR}/lib/"
cp /tmp/apache-log4j-${LOG4J_VER}-bin/log4j-api-${LOG4J_VER}.jar "${TOMCAT_DIR}/lib/"
rm -rf /tmp/log4j* /tmp/apache-log4j-*

# Tomcat manager config
cat > "${TOMCAT_DIR}/conf/tomcat-users.xml" <<'TOMCATUSERS'
<?xml version="1.0" encoding="UTF-8"?>
<tomcat-users xmlns="http://tomcat.apache.org/xml">
    <role rolename="manager-gui"/><role rolename="manager-script"/><role rolename="admin-gui"/>
    <user username="admin" password="admin" roles="manager-gui,manager-script,admin-gui"/>
    <user username="tomcat" password="tomcat" roles="manager-gui"/>
</tomcat-users>
TOMCATUSERS

# Allow remote access to manager
MANAGER_CTX="${TOMCAT_DIR}/webapps/manager/META-INF/context.xml"
[ -f "$MANAGER_CTX" ] && sed -i 's/allow="127\\.\\d+\\.\\d+\\.\\d+|::1|0:0:0:0:0:0:0:1"/allow=".*"/' "$MANAGER_CTX"

# Deploy Java banking app
if [ -d "${SCRIPT_DIR}/java-app" ]; then
    WEBAPP="${TOMCAT_DIR}/webapps/bankingapp"
    mkdir -p "${WEBAPP}/WEB-INF/classes/com/bankapp" "${WEBAPP}/WEB-INF/lib"
    cp "${TOMCAT_DIR}/lib/log4j-"*.jar "${WEBAPP}/WEB-INF/lib/" 2>/dev/null
    
    [ -f "${SCRIPT_DIR}/java-app/src/main/webapp/WEB-INF/web.xml" ] && \
        cp "${SCRIPT_DIR}/java-app/src/main/webapp/WEB-INF/web.xml" "${WEBAPP}/WEB-INF/"
    [ -f "${SCRIPT_DIR}/java-app/src/main/resources/log4j2.xml" ] && \
        cp "${SCRIPT_DIR}/java-app/src/main/resources/log4j2.xml" "${WEBAPP}/WEB-INF/classes/"
    
    JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java)))) 2>/dev/null
    JAVA_SRC="${SCRIPT_DIR}/java-app/src/main/java/com/bankapp/BankingServlet.java"
    [ -f "$JAVA_SRC" ] && javac -cp "${WEBAPP}/WEB-INF/lib/*:${TOMCAT_DIR}/lib/*" \
        -d "${WEBAPP}/WEB-INF/classes" "$JAVA_SRC" 2>/dev/null
fi

useradd -r -m -d "${TOMCAT_DIR}" -s /bin/false tomcat 2>/dev/null || true
chown -R tomcat:tomcat "${TOMCAT_DIR}"
chmod -R 755 "${TOMCAT_DIR}"

# Tomcat systemd service
cat > /etc/systemd/system/tomcat.service <<TOMCATSVC
[Unit]
Description=Apache Tomcat 9
After=network.target mysql.service

[Service]
Type=forking
User=tomcat
Group=tomcat
Environment="JAVA_HOME=${JAVA_HOME:-/usr/lib/jvm/default-java}"
Environment="CATALINA_HOME=${TOMCAT_DIR}"
ExecStart=${TOMCAT_DIR}/bin/startup.sh
ExecStop=${TOMCAT_DIR}/bin/shutdown.sh
Restart=on-failure

[Install]
WantedBy=multi-user.target
TOMCATSVC

systemctl daemon-reload
systemctl enable tomcat 2>/dev/null

###############################################################################
# 7. WordPress + Vulnerable Plugin
###############################################################################
log "Installing WordPress..."
wget -q https://wordpress.org/latest.tar.gz -O /tmp/wordpress.tar.gz 2>/dev/null
if [ -f /tmp/wordpress.tar.gz ]; then
    mkdir -p "${APP_DIR}/wordpress"
    tar -xzf /tmp/wordpress.tar.gz -C "${APP_DIR}/wordpress" --strip-components=1
    rm -f /tmp/wordpress.tar.gz
    
    if [ -f "${APP_DIR}/wordpress/wp-config-sample.php" ]; then
        cp "${APP_DIR}/wordpress/wp-config-sample.php" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/database_name_here/wordpress_db/" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/username_here/${MYSQL_APP_USER}/" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/password_here/${MYSQL_APP_PASS}/" "${APP_DIR}/wordpress/wp-config.php"
        echo "define('DISALLOW_FILE_EDIT', false);" >> "${APP_DIR}/wordpress/wp-config.php"
        echo "define('FS_METHOD', 'direct');" >> "${APP_DIR}/wordpress/wp-config.php"
    fi
    
    # Vulnerable plugin
    if [ -d "${SCRIPT_DIR}/wordpress-plugin" ]; then
        mkdir -p "${APP_DIR}/wordpress/wp-content/plugins/developer-flavor/developer-flavor-hash-form/"
        cp "${SCRIPT_DIR}/wordpress-plugin/"* "${APP_DIR}/wordpress/wp-content/plugins/developer-flavor/developer-flavor-hash-form/"
    fi
    
    chown -R www-data:www-data "${APP_DIR}/wordpress"
    chmod -R 777 "${APP_DIR}/wordpress/wp-content"
fi

###############################################################################
# 8. SSH (weak config)
###############################################################################
log "Configuring SSH (weak)..."
cat > /etc/ssh/sshd_config <<'SSHCONF'
Port 22
ListenAddress 0.0.0.0
PasswordAuthentication yes
PermitEmptyPasswords no
PermitRootLogin yes
MaxAuthTries 100
LoginGraceTime 120
Banner /etc/ssh/banner
X11Forwarding yes
AllowTcpForwarding yes
GatewayPorts yes
Ciphers aes128-ctr,aes192-ctr,aes256-ctr,aes128-cbc,3des-cbc
MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512
LogLevel VERBOSE
UsePAM yes
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
SSHCONF

cat > /etc/ssh/banner <<'BANNER'
************************************************************
*         INTERNAL BANKING SYSTEM - AUTHORIZED ONLY        *
*   Banking Portal Server v2.4.1 - Ubuntu 22.04 LTS       *
*   Unauthorized access is strictly prohibited             *
*   All sessions are monitored and logged                  *
************************************************************
BANNER

systemctl restart sshd 2>/dev/null || service ssh restart

###############################################################################
# 9. Users + Privilege Escalation
###############################################################################
log "Creating users and privilege escalation paths..."

# Create low-privilege users
useradd -m -s /bin/bash lowpriv 2>/dev/null; echo "lowpriv:lowpriv123" | chpasswd
useradd -m -s /bin/bash ubicd4 2>/dev/null; echo "ubicd4:UbiCD4@2024" | chpasswd

# Sudo misconfiguration
echo "lowpriv ALL=(ALL) NOPASSWD: /usr/bin/find, /usr/bin/vim, /usr/bin/python3" > /etc/sudoers.d/lowpriv
chmod 440 /etc/sudoers.d/lowpriv

# World-writable cron job
cat > /home/lowpriv/pwn.sh <<'CRONSCRIPT'
#!/bin/bash
find /tmp -type f -name "*.tmp" -mtime +7 -delete 2>/dev/null
echo "Cleanup completed at $(date)" >> /var/log/maintenance.log
CRONSCRIPT
chown lowpriv:lowpriv /home/lowpriv/pwn.sh
chmod 777 /home/lowpriv/pwn.sh
echo "* * * * * root /home/lowpriv/pwn.sh" > /etc/cron.d/maintenance-job
chmod 644 /etc/cron.d/maintenance-job

# SUID binary
if [ -f "${SCRIPT_DIR}/suid_helper.c" ]; then
    gcc -o /usr/local/bin/logviewer "${SCRIPT_DIR}/suid_helper.c"
    chmod u+s /usr/local/bin/logviewer
    chown root:root /usr/local/bin/logviewer
fi
cp /usr/bin/find /usr/local/bin/find-util
chmod u+s /usr/local/bin/find-util

###############################################################################
# 10. Disable security features
###############################################################################
log "Weakening OS security..."

# Disable ASLR
echo 0 > /proc/sys/kernel/randomize_va_space 2>/dev/null
echo "kernel.randomize_va_space = 0" >> /etc/sysctl.conf

# Disable AppArmor
systemctl stop apparmor 2>/dev/null
systemctl disable apparmor 2>/dev/null

# Flush iptables
iptables -F 2>/dev/null
iptables -P INPUT ACCEPT 2>/dev/null
iptables -P FORWARD ACCEPT 2>/dev/null
iptables -P OUTPUT ACCEPT 2>/dev/null

###############################################################################
# 11. Start services
###############################################################################
log "Starting all services..."

systemctl restart mysql
systemctl restart apache2
systemctl start tomcat
systemctl restart cron
systemctl restart ssh

sleep 3

###############################################################################
# 12. Validation
###############################################################################
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Setup complete! Service status:${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"

check_service() {
    if curl -s -o /dev/null -w "%{http_code}" "$1" | grep -q "200\|302"; then
        echo -e "  ${GREEN}[✓]${NC} $2"
    else
        echo -e "  ${RED}[✗]${NC} $2"
    fi
}

check_service "http://localhost/" "Banking Portal (port 80)"
check_service "http://localhost:8888/" "Customer Support Portal (port 8888)"
check_service "http://localhost:8080/" "Tomcat (port 8080)"
check_service "http://localhost/api/internal.php" "Internal API"

mysqladmin ping -u root -p"${MYSQL_ROOT_PASS}" --silent 2>/dev/null && \
    echo -e "  ${GREEN}[✓]${NC} MySQL (port 3306)" || \
    echo -e "  ${RED}[✗]${NC} MySQL (port 3306)"

ss -tlnp | grep -q ":22 " && \
    echo -e "  ${GREEN}[✓]${NC} SSH (port 22)" || \
    echo -e "  ${RED}[✗]${NC} SSH (port 22)"

echo ""
echo -e "${RED}⚠  THIS SYSTEM IS INTENTIONALLY VULNERABLE${NC}"
echo -e "${RED}⚠  USE ONLY IN ISOLATED NETWORK ENVIRONMENTS${NC}"
echo ""
echo -e "${GREEN}Access:${NC}"
echo "  Banking Portal:    http://<IP>/"
echo "  Support Portal:    http://<IP>:8888/"
echo "  Tomcat Manager:    http://<IP>:8080/manager/"
echo "  SSH:               ssh lowpriv@<IP> (password: lowpriv123)"
echo ""
