<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipient = $_POST['recipient'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $body = $_POST['body'] ?? '';
    
    // VULNERABLE: No input sanitization - Stored XSS
    // Body is stored as-is and rendered without escaping in dashboard and here
    $stmt = $db->prepare("INSERT INTO messages (sender, recipient, subject, body) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_SESSION['username'], $recipient, $subject, $body);
    
    if ($stmt->execute()) {
        $message = "Message sent successfully";
        $ip = $_SERVER['REMOTE_ADDR'];
        $db->query("INSERT INTO audit_logs (user, action, details, ip_address, status) VALUES ('{$_SESSION['username']}', 'SEND_MESSAGE', 'Sent message to $recipient', '$ip', 'success')");
    }
}

$inbox = $db->query("SELECT * FROM messages WHERE recipient='{$_SESSION['username']}' ORDER BY created_at DESC");
$sent = $db->query("SELECT * FROM messages WHERE sender='{$_SESSION['username']}' ORDER BY created_at DESC");
$users = $db->query("SELECT username, full_name FROM users WHERE status='active'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header">
                <h2>Internal Messages</h2>
                <p>Secure internal communication system</p>
            </div>
            
            <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
            
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-header"><h3>Inbox</h3></div>
                    <?php while($msg = $inbox->fetch_assoc()): ?>
                    <div class="message-item <?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                        <div class="msg-sender">From: <?php echo htmlspecialchars($msg['sender']); ?></div>
                        <div class="msg-subject"><?php echo htmlspecialchars($msg['subject']); ?></div>
                        <!-- VULNERABLE: Body rendered WITHOUT htmlspecialchars - Stored XSS -->
                        <div class="msg-preview"><?php echo $msg['body']; ?></div>
                        <div class="msg-date"><?php echo date('d-M-Y H:i', strtotime($msg['created_at'])); ?></div>
                    </div>
                    <?php endwhile; ?>
                </div>
                
                <div class="content-card">
                    <div class="card-header"><h3>Compose Message</h3></div>
                    <div class="form-container">
                        <form method="POST">
                            <div class="form-group">
                                <label>To</label>
                                <select name="recipient" required>
                                    <option value="">-- Select Recipient --</option>
                                    <?php while($u = $users->fetch_assoc()): ?>
                                    <option value="<?php echo $u['username']; ?>"><?php echo $u['full_name']; ?> (<?php echo $u['username']; ?>)</option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Subject</label>
                                <input type="text" name="subject" required placeholder="Message subject">
                            </div>
                            <div class="form-group">
                                <label>Message Body</label>
                                <textarea name="body" rows="5" required placeholder="Type your message here..."></textarea>
                            </div>
                            <button type="submit" class="btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
<?php $db->close(); ?>
