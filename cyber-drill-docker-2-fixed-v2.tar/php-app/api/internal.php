<?php
// Internal API - Nested API Endpoint
// VULNERABLE: No authentication, exposes internal operations
// Matches Drill III & IV "Nested API-Based Attack" scenarios

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$db = get_db();

// VULNERABLE: This "internal" API has no authentication check
// It is intended to be called by other internal services but is accessible externally

switch ($action) {
    case 'get_config':
        // VULNERABLE: Exposes application configuration
        $result = $db->query("SELECT * FROM config");
        if ($result === false) {
            // Keep it "internal" and leaky, but avoid hard 500s so validators can proceed
            echo json_encode(['status' => 'error', 'error' => $db->error]);
            break;
        }
        $configs = [];
        while ($row = $result->fetch_assoc()) {
            $configs[$row['config_key']] = $row['config_value'];
        }
        echo json_encode(['status' => 'success', 'config' => $configs]);
        break;
    
    case 'get_all_users':
        // VULNERABLE: Exposes all user data including PAN, Aadhaar
        $result = $db->query("SELECT * FROM users");
        $users = [];
        while ($row = $result->fetch_assoc()) $users[] = $row;
        echo json_encode(['status' => 'success', 'users' => $users]);
        break;
    
    case 'execute_query':
        // VULNERABLE: Arbitrary SQL query execution
        $query = $_POST['query'] ?? $_GET['query'] ?? '';
        if (!empty($query)) {
            $result = $db->query($query);
            if ($result === false) {
                echo json_encode(['error' => $db->error]);
            } elseif ($result === true) {
                echo json_encode(['status' => 'success', 'affected_rows' => $db->affected_rows]);
            } else {
                $data = [];
                while ($row = $result->fetch_assoc()) $data[] = $row;
                echo json_encode(['status' => 'success', 'data' => $data]);
            }
        } else {
            echo json_encode(['error' => 'No query provided']);
        }
        break;
    
    case 'system_info':
        // VULNERABLE: Server information disclosure
        echo json_encode([
            'status' => 'success',
            'server' => [
                'hostname' => gethostname(),
                'os' => php_uname(),
                'php_version' => phpversion(),
                'document_root' => $_SERVER['DOCUMENT_ROOT'],
                'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? '',
                'server_addr' => $_SERVER['SERVER_ADDR'] ?? '',
                'loaded_extensions' => get_loaded_extensions(),
                'mysql_version' => $db->server_info
            ]
        ]);
        break;
    
    case 'health_check':
        echo json_encode([
            'status' => 'healthy',
            'services' => [
                'mysql' => $db->ping() ? 'up' : 'down',
                'apache' => 'up',
                'php' => 'up'
            ],
            'uptime' => shell_exec('uptime'),
            'disk' => shell_exec('df -h / | tail -1')
        ]);
        break;
    
    default:
        echo json_encode([
            'error' => 'Unknown action',
            'available_actions' => ['get_config', 'get_all_users', 'execute_query', 'system_info', 'health_check'],
            'note' => 'This is an internal API for service-to-service communication'
        ]);
}

$db->close();
?>
