<?php
// VULNERABLE: Detailed error page exposing server info
$error_code = http_response_code();
?>
<!DOCTYPE html>
<html>
<head><title>Error - Banking Portal</title></head>
<body style="font-family:sans-serif;padding:40px;">
<h1>Application Error</h1>
<p>An error occurred while processing your request.</p>
<hr>
<pre>
Server: <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?>

PHP Version: <?php echo phpversion(); ?>

Document Root: <?php echo $_SERVER['DOCUMENT_ROOT']; ?>

Server Address: <?php echo $_SERVER['SERVER_ADDR'] ?? 'Unknown'; ?>

Request URI: <?php echo $_SERVER['REQUEST_URI']; ?>

Error Code: <?php echo $error_code; ?>

</pre>
</body>
</html>
