package com.bankapp;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Intentionally simple servlet used for the drill environment.
// NOTE: Vulnerability posture is intentionally unsafe elsewhere in the stack.
public class BankingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/plain");
        PrintWriter out = resp.getWriter();
        String ua = req.getHeader("User-Agent");
        if (ua == null) ua = "";
        // Deliberately echo user-controlled input (useful for drill demonstrations).
        out.println("bankingapp ok");
        out.println("ua=" + ua);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
