<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$txns = $db->query("SELECT * FROM transactions ORDER BY transaction_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header"><h2>Transaction History</h2><p>All transactions across branches</p></div>
            <div class="content-card">
                <div class="card-header"><h3>All Transactions</h3></div>
                <table class="data-table">
                    <thead><tr><th>TXN ID</th><th>From</th><th>To</th><th>Amount</th><th>Type</th><th>Description</th><th>Status</th><th>Channel</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php while($t = $txns->fetch_assoc()): ?>
                    <tr>
                        <td><code><?php echo $t['transaction_id']; ?></code></td>
                        <td><?php echo $t['from_account'] ?: '-'; ?></td>
                        <td><?php echo $t['to_account'] ?: '-'; ?></td>
                        <td class="amount">&#8377;<?php echo number_format($t['amount'], 2); ?></td>
                        <td><?php echo ucfirst(str_replace('_', ' ', $t['transaction_type'])); ?></td>
                        <td><?php echo $t['description']; ?></td>
                        <td><span class="badge badge-<?php echo $t['status']; ?>"><?php echo ucfirst($t['status']); ?></span></td>
                        <td><?php echo ucfirst($t['channel']); ?></td>
                        <td><?php echo date('d-M-Y H:i', strtotime($t['transaction_date'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
<?php $db->close(); ?>
