<?php
// Database Configuration - Banking Portal
// INTENTIONALLY contains hardcoded credentials for vulnerability demonstration

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'bankportal_db');
define('DB_USER', 'bankadmin');
define('DB_PASS', 'B@nkAdm1n_2024');

function get_db() {
    try {
        // Try socket connection first, then TCP
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            // VULNERABLE: Detailed error disclosure
            die("Database Connection Failed: " . $conn->connect_error . 
                " | Host: " . DB_HOST . " | User: " . DB_USER);
        }
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        die("Database Error: " . $e->getMessage());
    }
}

function get_pdo() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("PDO Error: " . $e->getMessage());
    }
}

// Session configuration - INTENTIONALLY WEAK
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 0);
    ini_set('session.cookie_secure', 0);
    ini_set('session.use_strict_mode', 0);
    session_start();
}

// JWT Configuration
define('JWT_SECRET', 'BankPortal_JWT_Weak_Secret_2024');

// Simple JWT encode/decode (intentionally weak)
function jwt_encode($payload) {
    $header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload_encoded = base64_encode(json_encode($payload));
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload_encoded", JWT_SECRET, true));
    return "$header.$payload_encoded.$signature";
}

function jwt_decode($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return false;
    
    // VULNERABLE: Does not verify 'none' algorithm
    $header = json_decode(base64_decode($parts[0]), true);
    if (isset($header['alg']) && $header['alg'] === 'none') {
        return json_decode(base64_decode($parts[1]), true);
    }
    
    $payload = json_decode(base64_decode($parts[1]), true);
    return $payload;
}
?>
