<?php $current = basename($_SERVER['PHP_SELF'] ?? $_SERVER['SCRIPT_NAME'] ?? ''); ?>
<aside class="sidebar">
    <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item <?php echo $current=='dashboard.php'?'active':''; ?>">
            <span class="nav-icon">📊</span> Dashboard
        </a>
        <a href="accounts.php" class="nav-item <?php echo $current=='accounts.php'?'active':''; ?>">
            <span class="nav-icon">🏦</span> Accounts
        </a>
        <a href="transfers.php" class="nav-item <?php echo $current=='transfers.php'?'active':''; ?>">
            <span class="nav-icon">💸</span> Fund Transfer
        </a>
        <a href="loans.php" class="nav-item <?php echo $current=='loans.php'?'active':''; ?>">
            <span class="nav-icon">📋</span> Loan Management
        </a>
        <a href="messages.php" class="nav-item <?php echo $current=='messages.php'?'active':''; ?>">
            <span class="nav-icon">✉️</span> Messages
        </a>
        <a href="transactions.php" class="nav-item <?php echo $current=='transactions.php'?'active':''; ?>">
            <span class="nav-icon">📑</span> Transactions
        </a>
        <?php if(($_SESSION['role'] ?? '') ==='admin' || ($_SESSION['role'] ?? '')==='manager' || ($_SESSION['role'] ?? '')==='cashier'): ?>
        <div class="nav-divider"></div>
        <span class="nav-section">Administration</span>
        <a href="users.php" class="nav-item <?php echo $current=='users.php'?'active':''; ?>">
            <span class="nav-icon">👥</span> User Management
        </a>
        <a href="audit.php" class="nav-item <?php echo $current=='audit.php'?'active':''; ?>">
            <span class="nav-icon">📝</span> Audit Logs
        </a>
        <a href="reports.php" class="nav-item <?php echo $current=='reports.php'?'active':''; ?>">
            <span class="nav-icon">📈</span> Reports
        </a>
        <a href="upload.php" class="nav-item <?php echo $current=='upload.php'?'active':''; ?>">
            <span class="nav-icon">📂</span> File Upload
        </a>
        <?php endif; ?>
    </nav>
</aside>
