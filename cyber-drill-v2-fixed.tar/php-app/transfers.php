<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/template.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }

$db = get_db();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_beneficiary') {
        $name = $_POST['beneficiary_name'] ?? '';
        $acc_num = $_POST['beneficiary_account'] ?? '';
        $ifsc = $_POST['beneficiary_ifsc'] ?? '';
        $bank = $_POST['beneficiary_bank'] ?? '';
        $nickname = $_POST['nickname'] ?? '';
        
        // VULNERABLE: Stores user input directly - Second-order SQL injection
        // The nickname is stored as-is and later used in template rendering
        $stmt = $db->prepare("INSERT INTO beneficiaries (user_id, beneficiary_name, account_number, ifsc_code, bank_name, nickname) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $_SESSION['user_id'], $name, $acc_num, $ifsc, $bank, $nickname);
        
        if ($stmt->execute()) {
            $message = "Beneficiary added successfully";
        } else {
            $error = "Failed to add beneficiary: " . $db->error;
        }
    }
    
    if ($action === 'initiate_transfer') {
        $from_acc = $_POST['from_account'] ?? '';
        $to_acc = $_POST['to_account'] ?? '';
        $amount = $_POST['amount'] ?? 0;
        $description = $_POST['description'] ?? '';
        
        // VULNERABLE: Template engine processes the description field →92 SSTI
        // Matches Drill II & IV SSTI payloads: {{8*8}}, {{system('whoami')}}
        $template = get_template_engine();
        $template->assign('sender', $_SESSION['username']);
        $template->assign('amount', $amount);
        
        // The description/remarks field is processed through the template engine
        $processed_description = $template->render($description);
        
        $txn_id = 'TXN' . date('YmdHis') . rand(100, 999);
        $stmt = $db->prepare("INSERT INTO transactions (transaction_id, from_account, to_account, amount, transaction_type, description, status, initiated_by, channel) VALUES (?, ?, ?, ?, 'transfer', ?, 'pending', ?, 'online')");
        $stmt->bind_param("sssdss", $txn_id, $from_acc, $to_acc, $amount, $processed_description, $_SESSION['username']);
        
        if ($stmt->execute()) {
            $message = "Transfer initiated. Transaction ID: $txn_id";
            
            // Log the transfer
            $ip = $_SERVER['REMOTE_ADDR'];
            $db->query("INSERT INTO audit_logs (user, action, details, ip_address, status) 
                        VALUES ('{$_SESSION['username']}', 'TRANSFER', 'Initiated transfer $txn_id for amount $amount', '$ip', 'success')");
        } else {
            $error = "Transfer failed: " . $db->error;
        }
    }
}

// Fetch user's accounts
$accounts = $db->query("SELECT * FROM accounts WHERE user_id = {$_SESSION['user_id']} OR 1=1");
$beneficiaries = $db->query("SELECT * FROM beneficiaries WHERE user_id = {$_SESSION['user_id']}");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Transfer - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header">
                <h2>Fund Transfer</h2>
                <p>Initiate internal and external fund transfers</p>
            </div>
            
            <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>
            
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-header"><h3>Initiate Transfer</h3></div>
                    <div class="form-container">
                        <form method="POST">
                            <input type="hidden" name="action" value="initiate_transfer">
                            <div class="form-group">
                                <label>From Account</label>
                                <select name="from_account" required>
                                    <option value="">-- Select Account --</option>
                                    <?php while($acc = $accounts->fetch_assoc()): ?>
                                    <option value="<?php echo $acc['account_number']; ?>">
                                        <?php echo $acc['account_number']; ?> - <?php echo $acc['account_holder']; ?> 
                                        (&#8377;<?php echo number_format($acc['balance'], 2); ?>)
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>To Account / Beneficiary</label>
                                <select name="to_account" required>
                                    <option value="">-- Select Beneficiary --</option>
                                    <?php 
                                    if ($beneficiaries && $beneficiaries->num_rows > 0):
                                        while($ben = $beneficiaries->fetch_assoc()): ?>
                                    <option value="<?php echo $ben['account_number']; ?>">
                                        <?php echo $ben['nickname']; ?> - <?php echo $ben['account_number']; ?> (<?php echo $ben['bank_name']; ?>)
                                    </option>
                                    <?php endwhile; endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Amount (&#8377;)</label>
                                <input type="number" name="amount" step="0.01" min="1" required placeholder="Enter transfer amount">
                            </div>
                            <div class="form-group">
                                <label>Remarks / Description</label>
                                <textarea name="description" rows="3" placeholder="Enter transfer remarks (e.g., Salary payment, Vendor payment)"></textarea>
                                <!-- SSTI: This field is processed through the template engine -->
                            </div>
                            <button type="submit" class="btn-primary">Initiate Transfer</button>
                        </form>
                    </div>
                </div>
                
                <div class="content-card">
                    <div class="card-header"><h3>Add Beneficiary</h3></div>
                    <div class="form-container">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_beneficiary">
                            <div class="form-group">
                                <label>Beneficiary Name</label>
                                <input type="text" name="beneficiary_name" required placeholder="Full name as per bank records">
                            </div>
                            <div class="form-group">
                                <label>Account Number</label>
                                <input type="text" name="beneficiary_account" required placeholder="Beneficiary account number">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>IFSC Code</label>
                                    <input type="text" name="beneficiary_ifsc" required placeholder="e.g., SBIN0001234">
                                </div>
                                <div class="form-group">
                                    <label>Bank Name</label>
                                    <input type="text" name="beneficiary_bank" required placeholder="Bank name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Nickname</label>
                                <input type="text" name="nickname" placeholder="Short name for reference">
                            </div>
                            <button type="submit" class="btn-secondary">Add Beneficiary</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="content-card">
                <div class="card-header"><h3>Pending Transfers</h3></div>
                <table class="data-table">
                    <thead><tr><th>TXN ID</th><th>From</th><th>To</th><th>Amount</th><th>Description</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php
                    $pending = $db->query("SELECT * FROM transactions WHERE status='pending' ORDER BY transaction_date DESC LIMIT 10");
                    while($txn = $pending->fetch_assoc()):
                    ?>
                    <tr>
                        <td><code><?php echo $txn['transaction_id']; ?></code></td>
                        <td><?php echo $txn['from_account']; ?></td>
                        <td><?php echo $txn['to_account']; ?></td>
                        <td class="amount">&#8377;<?php echo number_format($txn['amount'], 2); ?></td>
                        <!-- VULNERABLE: Rendered description may contain SSTI output -->
                        <td><?php echo $txn['description']; ?></td>
                        <td><span class="badge badge-<?php echo $txn['status']; ?>"><?php echo ucfirst($txn['status']); ?></span></td>
                        <td><?php echo date('d-M-Y H:i', strtotime($txn['transaction_date'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="content-card">
                <div class="card-header"><h3>Saved Beneficiaries</h3></div>
                <div id="benTxnResult" style="display:none;padding:10px 20px;"></div>
                <table class="data-table">
                    <thead><tr><th>Nickname</th><th>Name</th><th>Account #</th><th>Bank</th><th>IFSC</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php
                    $all_bens = $db->query("SELECT * FROM beneficiaries WHERE user_id = {$_SESSION['user_id']}");
                    if ($all_bens && $all_bens->num_rows > 0):
                        while($ben = $all_bens->fetch_assoc()):
                    ?>
                    <tr>
                        <!-- VULNERABLE: Nickname displayed without escaping - Second-order XSS/SQLi indicator -->
                        <td><?php echo $ben['nickname']; ?></td>
                        <td><?php echo htmlspecialchars($ben['beneficiary_name']); ?></td>
                        <td><code><?php echo $ben['account_number']; ?></code></td>
                        <td><?php echo htmlspecialchars($ben['bank_name']); ?></td>
                        <td><code><?php echo $ben['ifsc_code']; ?></code></td>
                        <td><span class="badge badge-<?php echo $ben['status']; ?>"><?php echo ucfirst($ben['status']); ?></span></td>
                        <td><a href="#" onclick="viewBenHistory(<?php echo $ben['id']; ?>)" class="btn-link">View History</a></td>
                    </tr>
                    <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
    <script>
    function viewBenHistory(benId) {
        fetch('/api/accounts.php?api=beneficiary_transactions&ben_id=' + benId)
            .then(r => r.json())
            .then(d => {
                var el = document.getElementById('benTxnResult');
                el.style.display = 'block';
                el.innerHTML = '<pre style="background:#f0f2f5;padding:10px;border-radius:6px;font-size:11px;max-height:300px;overflow:auto;">' + JSON.stringify(d, null, 2) + '</pre>';
            });
    }
    </script>
</body>
</html>
<?php $db->close(); ?>
