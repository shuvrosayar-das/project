<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header"><h2>Reports</h2><p>Generate and download operational reports</p></div>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#003580;">&#128202;</div>
                    <div class="stat-info">
                        <?php $r = $db->query("SELECT COUNT(*) as c FROM transactions")->fetch_assoc(); ?>
                        <span class="stat-value"><?php echo $r['c']; ?></span>
                        <span class="stat-label">Total Transactions</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#E31837;">&#128203;</div>
                    <div class="stat-info">
                        <?php $r = $db->query("SELECT SUM(amount) as t FROM transactions WHERE status='completed'")->fetch_assoc(); ?>
                        <span class="stat-value">&#8377;<?php echo number_format($r['t'] ?? 0, 0); ?></span>
                        <span class="stat-label">Total Volume</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#003580;">&#127974;</div>
                    <div class="stat-info">
                        <?php $r = $db->query("SELECT COUNT(*) as c FROM branches")->fetch_assoc(); ?>
                        <span class="stat-value"><?php echo $r['c']; ?></span>
                        <span class="stat-label">Active Branches</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#B8102A;">&#9888;</div>
                    <div class="stat-info">
                        <?php $r = $db->query("SELECT COUNT(*) as c FROM audit_logs WHERE status='failure'")->fetch_assoc(); ?>
                        <span class="stat-value"><?php echo $r['c']; ?></span>
                        <span class="stat-label">Failed Actions</span>
                    </div>
                </div>
            </div>
            <div class="alert alert-info">Reports module is operational. Use the API endpoints for custom data extraction.</div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
<?php $db->close(); ?>
