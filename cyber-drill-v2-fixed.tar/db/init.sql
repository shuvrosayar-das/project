-- ============================================================================
-- Banking Portal - Database Initialization
-- Cyber Drill VM - Intentionally Vulnerable Banking Application
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================================
-- Users Table (employees and customers)
-- ============================================================================
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100),
    `email` VARCHAR(100),
    `phone` VARCHAR(20),
    `role` ENUM('admin','manager','clerk','cashier','customer') DEFAULT 'customer',
    `employee_id` VARCHAR(20),
    `branch_code` VARCHAR(10),
    `department` VARCHAR(50),
    `api_token` VARCHAR(255),
    `pan_number` VARCHAR(15),
    `aadhaar_number` VARCHAR(20),
    `address` TEXT,
    `status` ENUM('active','inactive','locked') DEFAULT 'active',
    `last_login` DATETIME,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `login_attempts` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES
(1, 'admin', '0e7517141fb53f21ee439b355b5a1d0a', 'Rajesh Kumar Verma', 'admin@bankportal.internal', '9876543210', 'admin', 'EMP001', 'HO-001', 'IT Security', 'at_admin_2024_x9fk3m', 'ABCDE1234F', '1234-5678-9012', 'Head Office, Mumbai', 'active', NOW(), NOW(), 0),
(2, 'rk_sharma', '7ccbad448abbc8eeb5d417b90c91c748', 'Rakesh Kumar Sharma', 'rk.sharma@bankportal.internal', '9876543211', 'manager', 'EMP002', 'BR-101', 'Retail Banking', 'at_mgr_2024_p2q4r6', 'FGHIJ5678K', '2345-6789-0123', 'Branch 101, Delhi', 'active', NOW(), NOW(), 0),
(3, 'priya_m', '561f8c2acb033aee4b4465f04c1cee02', 'Priya Mukherjee', 'priya.m@bankportal.internal', '9876543212', 'clerk', 'EMP003', 'BR-101', 'Operations', 'at_clk_2024_t5u7v9', 'KLMNO9012P', '3456-7890-1234', 'Branch 101, Delhi', 'active', NOW(), NOW(), 0),
(4, 'amit_p', '712ee53479e594a3eb035aed58bc7e9c', 'Amit Patel', 'amit.p@bankportal.internal', '9876543213', 'cashier', 'EMP004', 'BR-202', 'Loan Processing', 'at_clk_2024_w8x0y2', 'PQRST3456U', '4567-8901-2345', 'Branch 202, Ahmedabad', 'active', NOW(), NOW(), 0),
(5, 'customer1', '5f4dcc3b5aa765d61d8327deb882cf99', 'Suresh Reddy', 'suresh@gmail.com', '9876543214', 'customer', NULL, 'BR-101', NULL, NULL, 'VWXYZ7890A', '5678-9012-3456', '45 MG Road, Bangalore', 'active', NOW(), NOW(), 0);

-- Passwords: admin=Admin@123, rk_sharma=Manager@2024, priya_m=Clerk@2024, amit_p=Cashier@2024, customer1=password

-- ============================================================================
-- Accounts Table
-- ============================================================================
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `account_number` VARCHAR(20) NOT NULL UNIQUE,
    `account_holder` VARCHAR(100),
    `account_type` ENUM('savings','current','loan','fixed_deposit') DEFAULT 'savings',
    `balance` DECIMAL(15,2) DEFAULT 0.00,
    `branch_code` VARCHAR(10),
    `ifsc_code` VARCHAR(15),
    `status` ENUM('active','dormant','frozen','closed') DEFAULT 'active',
    `pan_number` VARCHAR(15),
    `nominee` VARCHAR(100),
    `opening_date` DATE,
    `user_id` INT,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `accounts` VALUES
(1, '10010023456789', 'Rajesh Kumar Verma', 'savings', 4523189.75, 'HO-001', 'UBIN0HO0001', 'active', 'ABCDE1234F', 'Smt. Kavita Verma', '2019-03-15', 1),
(2, '10010034567890', 'Rakesh Kumar Sharma', 'current', 12897456.50, 'BR-101', 'UBIN0BR0101', 'active', 'FGHIJ5678K', 'Smt. Anita Sharma', '2020-01-10', 2),
(3, '10010045678901', 'Priya Mukherjee', 'savings', 876543.25, 'BR-101', 'UBIN0BR0101', 'active', 'KLMNO9012P', 'Sri Subhash Mukherjee', '2021-06-22', 3),
(4, '10010056789012', 'Amit Patel', 'savings', 345678.90, 'BR-202', 'UBIN0BR0202', 'active', 'PQRST3456U', 'Smt. Meera Patel', '2022-02-14', 4),
(5, '10010067890123', 'Suresh Reddy', 'savings', 1234567.80, 'BR-101', 'UBIN0BR0101', 'active', 'VWXYZ7890A', 'Sri Kumar Reddy', '2023-08-01', 5),
(6, '20020012345678', 'ABC Traders Pvt Ltd', 'current', 45678901.00, 'BR-202', 'UBIN0BR0202', 'active', 'AABCA1234B', 'Directors - ABC Traders', '2018-11-30', NULL),
(7, '30030023456789', 'Deepak Mishra', 'loan', -2500000.00, 'BR-101', 'UBIN0BR0101', 'active', 'BCDEF2345G', 'Smt. Ritu Mishra', '2024-01-05', NULL),
(8, '40040034567890', 'Kavita Singh', 'fixed_deposit', 5000000.00, 'HO-001', 'UBIN0HO0001', 'active', 'CDEFG3456H', 'Sri Vikram Singh', '2023-04-18', NULL);

-- ============================================================================
-- Transactions Table
-- ============================================================================
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(30) NOT NULL UNIQUE,
    `from_account` VARCHAR(20),
    `to_account` VARCHAR(20),
    `amount` DECIMAL(15,2),
    `transaction_type` ENUM('credit','debit','transfer','loan_emi','interest') DEFAULT 'transfer',
    `description` TEXT,
    `status` ENUM('completed','pending','failed','reversed') DEFAULT 'completed',
    `initiated_by` VARCHAR(50),
    `approved_by` VARCHAR(50),
    `transaction_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `channel` ENUM('branch','online','mobile','atm','api') DEFAULT 'branch',
    `reference_number` VARCHAR(30)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `transactions` VALUES
(1, 'TXN20241101001', '10010023456789', '10010034567890', 250000.00, 'transfer', 'Salary disbursement - November 2024', 'completed', 'admin', 'rk_sharma', '2024-11-01 10:30:00', 'branch', 'REF-NOV-001'),
(2, 'TXN20241102002', '10010034567890', '20020012345678', 1500000.00, 'transfer', 'Business account funding', 'completed', 'rk_sharma', 'admin', '2024-11-02 14:15:00', 'online', 'REF-NOV-002'),
(3, 'TXN20241103003', '10010045678901', '10010067890123', 50000.00, 'transfer', 'Personal transfer', 'completed', 'priya_m', NULL, '2024-11-03 09:45:00', 'mobile', 'REF-NOV-003'),
(4, 'TXN20241104004', '30030023456789', NULL, 45000.00, 'loan_emi', 'Home Loan EMI - November 2024', 'completed', 'system', NULL, '2024-11-04 00:01:00', 'api', 'REF-EMI-NOV'),
(5, 'TXN20241105005', NULL, '40040034567890', 125000.00, 'interest', 'FD Interest Credit - Q3 2024', 'completed', 'system', NULL, '2024-11-05 00:01:00', 'api', 'REF-INT-Q3'),
(6, 'TXN20241107006', '10010056789012', '10010023456789', 75000.00, 'transfer', 'Vendor payment - IT services', 'pending', 'amit_p', NULL, '2024-11-07 11:20:00', 'branch', 'REF-NOV-006'),
(7, 'TXN20241108007', '10010067890123', '10010045678901', 25000.00, 'transfer', 'Rent payment', 'completed', 'customer1', NULL, '2024-11-08 16:00:00', 'online', 'REF-NOV-007'),
(8, 'TXN20241110008', '20020012345678', '10010034567890', 500000.00, 'transfer', 'Profit distribution', 'failed', 'rk_sharma', NULL, '2024-11-10 13:30:00', 'branch', 'REF-NOV-008');

-- ============================================================================
-- Loans Table
-- ============================================================================
DROP TABLE IF EXISTS `loans`;
CREATE TABLE `loans` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `loan_id` VARCHAR(20) NOT NULL UNIQUE,
    `account_number` VARCHAR(20),
    `borrower_name` VARCHAR(100),
    `loan_type` ENUM('home','personal','vehicle','education','business') DEFAULT 'personal',
    `principal_amount` DECIMAL(15,2),
    `interest_rate` DECIMAL(5,2),
    `tenure_months` INT,
    `emi_amount` DECIMAL(15,2),
    `outstanding_balance` DECIMAL(15,2),
    `disbursement_date` DATE,
    `status` ENUM('active','closed','npa','restructured') DEFAULT 'active',
    `collateral_details` TEXT,
    `guarantor_name` VARCHAR(100),
    `guarantor_pan` VARCHAR(15),
    `approved_by` VARCHAR(50),
    `branch_code` VARCHAR(10)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `loans` VALUES
(1, 'HL-2024-001', '30030023456789', 'Deepak Mishra', 'home', 5000000.00, 8.50, 240, 43391.00, 2500000.00, '2024-01-05', 'active', 'Property at Sector 15, Noida - Market Value 8500000', 'Ritu Mishra', 'DEFGH4567I', 'rk_sharma', 'BR-101'),
(2, 'PL-2024-002', '10010045678901', 'Priya Mukherjee', 'personal', 500000.00, 12.00, 36, 16607.00, 350000.00, '2024-03-15', 'active', 'Unsecured', NULL, NULL, 'rk_sharma', 'BR-101'),
(3, 'VL-2024-003', '10010056789012', 'Amit Patel', 'vehicle', 800000.00, 9.75, 60, 16820.00, 650000.00, '2024-06-01', 'active', 'Maruti Suzuki Grand Vitara - Reg MH01AB1234', 'Meera Patel', 'EFGHI5678J', 'admin', 'BR-202'),
(4, 'BL-2023-004', '20020012345678', 'ABC Traders Pvt Ltd', 'business', 10000000.00, 11.25, 120, 138952.00, 8500000.00, '2023-06-15', 'active', 'Commercial property at MG Road, Ahmedabad', 'Rajesh Agarwal', 'FGHIJ6789K', 'admin', 'BR-202'),
(5, 'EL-2024-005', '10010067890123', 'Suresh Reddy', 'education', 1500000.00, 7.25, 84, 22500.00, 1200000.00, '2024-08-01', 'active', 'Unsecured - Education Loan for MS at Georgia Tech', 'Kumar Reddy', 'GHIJK7890L', 'rk_sharma', 'BR-101');

-- ============================================================================
-- Audit Logs Table
-- ============================================================================
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `user` VARCHAR(50),
    `action` VARCHAR(100),
    `details` TEXT,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `status` ENUM('success','failure','warning') DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `audit_logs` VALUES
(1, '2024-11-07 09:00:00', 'admin', 'LOGIN', 'Admin login from HO', '10.10.1.50', 'Mozilla/5.0', 'success'),
(2, '2024-11-07 09:15:00', 'rk_sharma', 'LOGIN', 'Manager login from Branch 101', '10.10.2.25', 'Mozilla/5.0', 'success'),
(3, '2024-11-07 10:30:00', 'admin', 'TRANSFER', 'Transfer TXN20241101001 approved', '10.10.1.50', 'Mozilla/5.0', 'success'),
(4, '2024-11-07 11:00:00', 'unknown', 'LOGIN', 'Failed login attempt', '59.163.35.4', 'python-requests/2.31.0', 'failure'),
(5, '2024-11-07 11:05:00', 'unknown', 'LOGIN', 'Failed login - SQL injection attempt detected', '59.163.35.4', 'sqlmap/1.7', 'failure'),
(6, '2024-11-07 13:02:00', 'unknown', 'LOGIN', 'Password spray detected - multiple accounts', '59.163.35.4', 'Burp Suite', 'failure'),
(7, '2024-11-07 14:30:00', 'priya_m', 'VIEW_ACCOUNT', 'Viewed account details for 10010067890123', '10.10.2.25', 'Mozilla/5.0', 'success'),
(8, '2024-11-07 15:00:00', 'system', 'BACKUP', 'Automated database backup completed', '127.0.0.1', 'cron', 'success');

-- ============================================================================
-- Internal Messages / Reviews (for Stored XSS)
-- ============================================================================
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `sender` VARCHAR(50),
    `recipient` VARCHAR(50),
    `subject` VARCHAR(200),
    `body` TEXT,
    `is_read` TINYINT DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `messages` VALUES
(1, 'admin', 'rk_sharma', 'Q3 Audit Report Review', 'Please review the Q3 audit findings and submit your response by EOD.', 0, '2024-11-07 09:30:00'),
(2, 'rk_sharma', 'priya_m', 'Pending Transfers', 'Please process the pending transfers in queue before 3 PM.', 1, '2024-11-07 10:00:00'),
(3, 'priya_m', 'admin', 'System Maintenance Request', 'The loan processing module needs maintenance window this weekend.', 0, '2024-11-07 11:00:00'),
(4, 'system', 'admin', 'Security Alert', 'Multiple failed login attempts detected from IP 59.163.35.4', 0, '2024-11-07 13:05:00'),
(5, 'amit_p', 'rk_sharma', 'Loan Approval Request', 'New business loan application for ABC Traders requires your approval.', 0, '2024-11-07 14:00:00');

-- ============================================================================
-- Branch Information Table
-- ============================================================================
DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `branch_code` VARCHAR(10) NOT NULL UNIQUE,
    `branch_name` VARCHAR(100),
    `address` TEXT,
    `city` VARCHAR(50),
    `state` VARCHAR(50),
    `ifsc_code` VARCHAR(15),
    `manager` VARCHAR(100),
    `phone` VARCHAR(20),
    `status` ENUM('active','closed','renovating') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `branches` VALUES
(1, 'HO-001', 'Head Office', 'Nariman Point, Mumbai', 'Mumbai', 'Maharashtra', 'UBIN0HO0001', 'Rajesh Kumar Verma', '022-22001001', 'active'),
(2, 'BR-101', 'Connaught Place Branch', 'Block A, Connaught Place', 'New Delhi', 'Delhi', 'UBIN0BR0101', 'Rakesh Kumar Sharma', '011-23001001', 'active'),
(3, 'BR-202', 'CG Road Branch', 'CG Road, Navrangpura', 'Ahmedabad', 'Gujarat', 'UBIN0BR0202', 'Manish Joshi', '079-26001001', 'active'),
(4, 'BR-303', 'Anna Salai Branch', '123 Anna Salai', 'Chennai', 'Tamil Nadu', 'UBIN0BR0303', 'Lakshmi Narayanan', '044-28001001', 'active'),
(5, 'BR-404', 'Park Street Branch', '88 Park Street', 'Kolkata', 'West Bengal', 'UBIN0BR0404', 'Soumya Banerjee', '033-22001001', 'active');

-- ============================================================================
-- Second-Order SQL Injection Support Table
-- ============================================================================
DROP TABLE IF EXISTS `beneficiaries`;
CREATE TABLE `beneficiaries` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT,
    `beneficiary_name` VARCHAR(100),
    `account_number` VARCHAR(20),
    `ifsc_code` VARCHAR(15),
    `bank_name` VARCHAR(100),
    `nickname` VARCHAR(255),
    `status` ENUM('active','pending','deleted') DEFAULT 'active',
    `added_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `beneficiaries` VALUES
(1, 1, 'Kavita Verma', '50500012345678', 'HDFC0001234', 'HDFC Bank', 'Wife', 'active', NOW()),
(2, 2, 'Anita Sharma', '60600023456789', 'SBIN0002345', 'State Bank of India', 'Wife', 'active', NOW()),
(3, 3, 'Subhash Mukherjee', '70700034567890', 'ICIC0003456', 'ICICI Bank', 'Father', 'active', NOW()),
(4, 1, 'Electric Board', '80800045678901', 'BARB0004567', 'Bank of Baroda', 'Utility', 'active', NOW()),
(5, 2, 'ABC Traders', '20020012345678', 'UBIN0BR0202', 'Internal', 'Business', 'active', NOW());

-- ============================================================================
-- Configuration Table (stores app config - sensitive data exposure)
-- ============================================================================
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `config_key` VARCHAR(100) NOT NULL UNIQUE,
    `config_value` TEXT,
    `description` VARCHAR(200),
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `config` VALUES
(1, 'jwt_secret', 'BankPortal_JWT_Weak_Secret_2024', 'JWT signing secret', NOW()),
(2, 'api_master_key', 'ak_live_bp2024_x9f2k3m5n7p1q4r6', 'Master API key', NOW()),
(3, 'smtp_password', 'EmailP@ss_2024!', 'SMTP server password', NOW()),
(4, 'backup_encryption_key', 'BackupKey_AES256_W3akP@ss', 'Database backup encryption', NOW()),
(5, 'admin_recovery_code', 'RECOV-2024-ADMIN-9876', 'Admin password recovery code', NOW());

SET FOREIGN_KEY_CHECKS = 1;
