#!/bin/bash
# CVE-2024-4577 Simulation Wrapper
# Simulates the vulnerable PHP-CGI argument parsing where soft-hyphen (0xAD)
# bypasses the CVE-2012-1823 argument filter

# Find the php-cgi binary
PHP_CGI=""
for bin in /usr/bin/php-cgi8.1 /usr/bin/php-cgi /usr/lib/cgi-bin/php; do
    [ -x "$bin" ] && PHP_CGI="$bin" && break
done
[ -z "$PHP_CGI" ] && { echo "Status: 500"; echo ""; echo "php-cgi not found"; exit 1; }

QUERY="${QUERY_STRING}"

# Simulate Best-Fit character mapping: convert %AD (soft hyphen) to - (regular hyphen)
# This is the core of CVE-2024-4577 — the bypass of CVE-2012-1823 protection
DECODED_QUERY=$(echo "$QUERY" | sed 's/%[Aa][Dd]/-/g')

# Check if decoded query contains PHP-CGI argument flags
if echo "$DECODED_QUERY" | grep -qE '(^|[+&])-[a-zA-Z]'; then
    ARGS=""
    # Split on + and & delimiters
    IFS='+&' read -ra PARAMS <<< "$DECODED_QUERY"
    for param in "${PARAMS[@]}"; do
        # URL decode basic sequences
        param=$(echo -e "$(echo "$param" | sed 's/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')")
        if [[ "$param" == -* ]]; then
            ARGS="$ARGS $param"
        fi
    done
    exec $PHP_CGI $ARGS
else
    export SCRIPT_FILENAME="$PATH_TRANSLATED"
    exec $PHP_CGI
fi
