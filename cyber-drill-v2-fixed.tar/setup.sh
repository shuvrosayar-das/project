#!/bin/bash
###############################################################################
# Union Bank of India - Cyber Drill VM Setup Script
# One-click deployment on Ubuntu 22.04 LTS (bare metal / VM)
# Usage: sudo bash setup.sh
###############################################################################

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; }
die()  { err "$1"; exit 1; }

[ "$EUID" -ne 0 ] && die "Run as root: sudo bash setup.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/var/www/html/bankportal"
CGI_DIR="/var/www/cgi-portal"
TOMCAT_DIR="/opt/tomcat"
TOMCAT_VER="9.0.65"
LOG4J_VER="2.14.1"
MYSQL_ROOT_PASS="R00t_MySQL_2024!"
MYSQL_APP_USER="bankadmin"
MYSQL_APP_PASS="B@nkAdm1n_2024"
export DEBIAN_FRONTEND=noninteractive

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   Union Bank of India - Cyber Drill VM Setup                ║"
echo "║   WARNING: INTENTIONALLY VULNERABLE                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── 1. PACKAGES (staged to isolate failures) ──
log "Updating package lists..."
for i in 1 2 3; do apt-get update -qq 2>/dev/null && break; sleep 3; done

log "Installing prerequisites..."
apt-get install -y debconf-utils ca-certificates curl wget gnupg2 software-properties-common 2>/dev/null || true

log "Installing Apache + PHP 8.1..."
apt-get install -y apache2 libapache2-mod-php8.1 \
    php8.1 php8.1-mysql php8.1-xml php8.1-mbstring php8.1-curl \
    php8.1-zip php8.1-gd php8.1-intl php8.1-soap php8.1-bcmath \
    php8.1-cli php8.1-cgi 2>/dev/null || warn "Some PHP packages failed"

log "Installing MySQL..."
apt-get install -y mysql-server mysql-client 2>/dev/null || die "MySQL install failed"

log "Installing Java..."
apt-get install -y default-jdk 2>/dev/null || apt-get install -y openjdk-11-jdk 2>/dev/null || warn "Java failed - Log4Shell won't work"

log "Installing utilities..."
apt-get install -y openssh-server cron at sudo vim nano python3 unzip net-tools build-essential gcc 2>/dev/null || true

a2enmod rewrite headers proxy proxy_http php8.1 actions cgi 2>/dev/null || true

# Verify critical commands
for cmd in apache2 php mysql sshd gcc; do
    command -v $cmd >/dev/null 2>&1 || die "Missing critical: $cmd"
done
log "All packages installed"

# ── 2. PHP CONFIG ──
log "Configuring PHP..."
for INI in /etc/php/8.1/apache2/php.ini /etc/php/8.1/cgi/php.ini /etc/php/8.1/cli/php.ini; do
    [ ! -f "$INI" ] && continue
    sed -i 's/^display_errors = Off/display_errors = On/' "$INI"
    sed -i 's/^display_startup_errors = Off/display_startup_errors = On/' "$INI"
    sed -i 's/^expose_php = Off/expose_php = On/' "$INI"
    sed -i 's/^;allow_url_include = Off/allow_url_include = On/' "$INI"
    sed -i 's/^allow_url_include = Off/allow_url_include = On/' "$INI"
    sed -i 's/^upload_max_filesize = 2M/upload_max_filesize = 50M/' "$INI"
    sed -i 's/^post_max_size = 8M/post_max_size = 50M/' "$INI"
    sed -i 's/^disable_functions = .*/disable_functions = /' "$INI"
    sed -i 's/^session.cookie_httponly = 1/session.cookie_httponly = 0/' "$INI"
done
CGI_INI=/etc/php/8.1/cgi/php.ini
if [ -f "$CGI_INI" ]; then
    sed -i 's/^;cgi.force_redirect = 1/cgi.force_redirect = 0/' "$CGI_INI"
    sed -i 's/^cgi.force_redirect = 1/cgi.force_redirect = 0/' "$CGI_INI"
    grep -q "^register_argc_argv = On" "$CGI_INI" || echo "register_argc_argv = On" >> "$CGI_INI"
fi
mkdir -p /var/lib/php/sessions && chmod 1733 /var/lib/php/sessions

# ── 3. MYSQL ──
log "Configuring MySQL..."
mkdir -p /var/run/mysqld && chown mysql:mysql /var/run/mysqld
systemctl start mysql 2>/dev/null || service mysql start 2>/dev/null
sleep 2

# Ubuntu 22.04 MySQL 8.0 uses auth_socket for root by default
MYSQL_CMD=""
if mysql -u root -e "SELECT 1" 2>/dev/null; then
    MYSQL_CMD="mysql -u root"
elif mysql -u root -p"${MYSQL_ROOT_PASS}" -e "SELECT 1" 2>/dev/null; then
    MYSQL_CMD="mysql -u root -p${MYSQL_ROOT_PASS}"
else
    warn "MySQL auth issue — using skip-grant-tables recovery..."
    systemctl stop mysql 2>/dev/null; sleep 2
    mysqld_safe --skip-grant-tables --skip-networking &
    for i in $(seq 1 15); do mysqladmin ping --silent 2>/dev/null && break; sleep 1; done
    MYSQL_CMD="mysql -u root"
fi

$MYSQL_CMD -e "CREATE DATABASE IF NOT EXISTS bankportal_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null
$MYSQL_CMD -e "CREATE DATABASE IF NOT EXISTS wordpress_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null

$MYSQL_CMD 2>/dev/null <<MSQL
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
DROP USER IF EXISTS '${MYSQL_APP_USER}'@'localhost';
DROP USER IF EXISTS '${MYSQL_APP_USER}'@'%';
CREATE USER '${MYSQL_APP_USER}'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_APP_PASS}';
CREATE USER '${MYSQL_APP_USER}'@'%' IDENTIFIED WITH mysql_native_password BY '${MYSQL_APP_PASS}';
CREATE USER '${MYSQL_APP_USER}'@'127.0.0.1' IDENTIFIED WITH mysql_native_password BY '${MYSQL_APP_PASS}';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'localhost';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'%';
GRANT ALL PRIVILEGES ON bankportal_db.* TO '${MYSQL_APP_USER}'@'127.0.0.1';
GRANT ALL PRIVILEGES ON wordpress_db.* TO '${MYSQL_APP_USER}'@'localhost';
GRANT ALL PRIVILEGES ON wordpress_db.* TO '${MYSQL_APP_USER}'@'%';
GRANT FILE ON *.* TO '${MYSQL_APP_USER}'@'localhost';
GRANT FILE ON *.* TO '${MYSQL_APP_USER}'@'%';
FLUSH PRIVILEGES;
MSQL

# Kill skip-grant-tables if running, restart normally
pgrep -f "skip-grant-tables" >/dev/null && { killall mysqld 2>/dev/null; sleep 3; systemctl start mysql 2>/dev/null; sleep 2; }

MYSQL_CMD="mysql -u root -p${MYSQL_ROOT_PASS}"
[ -f "${SCRIPT_DIR}/db/init.sql" ] && $MYSQL_CMD bankportal_db < "${SCRIPT_DIR}/db/init.sql" 2>/dev/null && log "Banking data imported"

# Weaken MySQL
MYCNF="/etc/mysql/mysql.conf.d/mysqld.cnf"
[ -f "$MYCNF" ] && {
    sed -i 's/^bind-address\s*=\s*127.0.0.1/bind-address = 0.0.0.0/' "$MYCNF"
    grep -q "^local-infile" "$MYCNF" || echo "local-infile=1" >> "$MYCNF"
    grep -q "^secure-file-priv" "$MYCNF" || echo 'secure-file-priv=""' >> "$MYCNF"
}
systemctl restart mysql 2>/dev/null
log "MySQL configured"

# ── 4. BANKING PORTAL (port 80) ──
log "Deploying banking portal..."
mkdir -p "${APP_DIR}"/{uploads,backup,templates,images,.ssh}
[ -d "${SCRIPT_DIR}/php-app" ] && cp -a "${SCRIPT_DIR}/php-app/." "${APP_DIR}/"
chown -R www-data:www-data "${APP_DIR}"; chmod -R 755 "${APP_DIR}"
chmod 777 "${APP_DIR}/uploads" "${APP_DIR}/templates" "${APP_DIR}/images"

echo 'AddHandler application/x-httpd-php .php .phtml .php5 .php7 .pht
Options +ExecCGI' > "${APP_DIR}/uploads/.htaccess"

cat > "${APP_DIR}/.env" << 'ENV'
APP_ENV=production
APP_DEBUG=true
DB_HOST=localhost
DB_DATABASE=bankportal_db
DB_USERNAME=bankadmin
DB_PASSWORD=B@nkAdm1n_2024
MYSQL_ROOT_PASSWORD=R00t_MySQL_2024!
JWT_SECRET=BankPortal_JWT_Weak_Secret_2024
API_KEY=ak_live_bp2024_x9f2k3m5n7p1q4r6
ENV

cat > "${APP_DIR}/.htaccess" << 'HT'
Options +Indexes +FollowSymLinks
RewriteEngine On
Header unset X-Frame-Options
Header unset X-Content-Type-Options
Header unset X-XSS-Protection
Header unset Content-Security-Policy
HT

ssh-keygen -t rsa -b 2048 -f "${APP_DIR}/.ssh/id_rsa" -N "" 2>/dev/null || true

cat > /etc/apache2/sites-available/bankportal.conf << 'VH'
<VirtualHost *:80>
    ServerName bankportal.local
    DocumentRoot /var/www/html/bankportal
    DirectoryIndex index.php index.html
    <Directory /var/www/html/bankportal>
        Options Indexes FollowSymLinks MultiViews
        AllowOverride All
        Require all granted
        DirectoryIndex index.php index.html
    </Directory>
    <FilesMatch "\.php$">
        SetHandler application/x-httpd-php
    </FilesMatch>
    ProxyPass /bankingapp http://localhost:8080/bankingapp
    ProxyPassReverse /bankingapp http://localhost:8080/bankingapp
    ErrorDocument 404 /error.php
    Header unset X-Frame-Options
    Header unset X-Content-Type-Options
    Header unset X-XSS-Protection
    Header unset Content-Security-Policy
    ErrorLog /var/log/apache2/bankportal-error.log
    CustomLog /var/log/apache2/bankportal-access.log combined
</VirtualHost>
VH

cat > /etc/apache2/conf-available/allow-uploads.conf << 'UP'
<Directory "/var/www/html/bankportal/uploads">
    Options +ExecCGI
    AddHandler application/x-httpd-php .php .phtml .php5
    Require all granted
</Directory>
UP

a2dissite 000-default.conf 2>/dev/null; a2ensite bankportal.conf 2>/dev/null; a2enconf allow-uploads 2>/dev/null
SEC="/etc/apache2/conf-enabled/security.conf"
[ -f "$SEC" ] && { sed -i 's/^ServerTokens.*/ServerTokens Full/' "$SEC"; sed -i 's/^ServerSignature.*/ServerSignature On/' "$SEC"; }
log "Banking portal deployed"

# ── 5. CGI PORTAL (port 8888) ──
log "Deploying Customer Support Portal (CVE-2024-4577)..."
mkdir -p "${CGI_DIR}" /usr/lib/cgi-bin
[ -d "${SCRIPT_DIR}/cgi-app" ] && cp -a "${SCRIPT_DIR}/cgi-app/." "${CGI_DIR}/"
[ -f "${SCRIPT_DIR}/cgi-bin-wrapper.sh" ] && cp "${SCRIPT_DIR}/cgi-bin-wrapper.sh" /usr/lib/cgi-bin/php-cgi-wrapper.sh && chmod +x /usr/lib/cgi-bin/php-cgi-wrapper.sh
chown -R www-data:www-data "${CGI_DIR}"

grep -q "^Listen 8888" /etc/apache2/ports.conf || echo "Listen 8888" >> /etc/apache2/ports.conf

cat > /etc/apache2/sites-available/cgi-portal.conf << 'CGI'
<VirtualHost *:8888>
    ServerName support.unionbank.internal
    DocumentRoot /var/www/cgi-portal
    DirectoryIndex index.php index.html
    ScriptAlias /cgi-bin/ /usr/lib/cgi-bin/
    Action php-cgi /cgi-bin/php-cgi-wrapper.sh
    AddHandler php-cgi .php
    <Directory /var/www/cgi-portal>
        Options +ExecCGI +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    <Directory /usr/lib/cgi-bin>
        Options +ExecCGI
        Require all granted
    </Directory>
    ServerSignature On
    ErrorLog /var/log/apache2/cgi-portal-error.log
    CustomLog /var/log/apache2/cgi-portal-access.log combined
</VirtualHost>
CGI
a2ensite cgi-portal.conf 2>/dev/null; a2enmod actions cgi 2>/dev/null
log "CGI portal deployed"

# ── 6. TOMCAT + LOG4J ──
log "Installing Tomcat ${TOMCAT_VER}..."
mkdir -p "${TOMCAT_DIR}"
wget -q "https://archive.apache.org/dist/tomcat/tomcat-9/v${TOMCAT_VER}/bin/apache-tomcat-${TOMCAT_VER}.tar.gz" -O /tmp/tomcat.tar.gz
[ -s /tmp/tomcat.tar.gz ] && tar -xzf /tmp/tomcat.tar.gz -C "${TOMCAT_DIR}" --strip-components=1 && rm /tmp/tomcat.tar.gz && log "Tomcat installed" || warn "Tomcat download failed"

wget -q "https://archive.apache.org/dist/logging/log4j/${LOG4J_VER}/apache-log4j-${LOG4J_VER}-bin.tar.gz" -O /tmp/log4j.tar.gz
[ -s /tmp/log4j.tar.gz ] && {
    tar -xzf /tmp/log4j.tar.gz -C /tmp/
    cp /tmp/apache-log4j-${LOG4J_VER}-bin/log4j-core-${LOG4J_VER}.jar "${TOMCAT_DIR}/lib/" 2>/dev/null
    cp /tmp/apache-log4j-${LOG4J_VER}-bin/log4j-api-${LOG4J_VER}.jar "${TOMCAT_DIR}/lib/" 2>/dev/null
    rm -rf /tmp/log4j* /tmp/apache-log4j-*
    log "Log4j installed"
} || warn "Log4j download failed"

[ -d "${TOMCAT_DIR}/conf" ] && cat > "${TOMCAT_DIR}/conf/tomcat-users.xml" << 'TC'
<?xml version="1.0" encoding="UTF-8"?>
<tomcat-users xmlns="http://tomcat.apache.org/xml">
    <role rolename="manager-gui"/><role rolename="manager-script"/><role rolename="admin-gui"/>
    <user username="admin" password="admin" roles="manager-gui,manager-script,admin-gui"/>
</tomcat-users>
TC
MCX="${TOMCAT_DIR}/webapps/manager/META-INF/context.xml"
[ -f "$MCX" ] && sed -i 's|allow="[^"]*"|allow=".*"|' "$MCX"

# Deploy Java app
WEBAPP="${TOMCAT_DIR}/webapps/bankingapp"
mkdir -p "${WEBAPP}/WEB-INF/classes/com/bankapp" "${WEBAPP}/WEB-INF/lib"
cp "${TOMCAT_DIR}/lib/log4j-"*.jar "${WEBAPP}/WEB-INF/lib/" 2>/dev/null
[ -f "${SCRIPT_DIR}/java-app/src/main/webapp/WEB-INF/web.xml" ] && cp "${SCRIPT_DIR}/java-app/src/main/webapp/WEB-INF/web.xml" "${WEBAPP}/WEB-INF/"
[ -f "${SCRIPT_DIR}/java-app/src/main/resources/log4j2.xml" ] && cp "${SCRIPT_DIR}/java-app/src/main/resources/log4j2.xml" "${WEBAPP}/WEB-INF/classes/"
JSRC="${SCRIPT_DIR}/java-app/src/main/java/com/bankapp/BankingServlet.java"
if [ -f "$JSRC" ]; then
    JAVA_HOME=$(dirname "$(dirname "$(readlink -f "$(which java)")")" 2>/dev/null)
    export JAVA_HOME
    # Build classpath by finding all jars explicitly (wildcard expansion issue fix)
    LIB_CP=$(find "${WEBAPP}/WEB-INF/lib" "${TOMCAT_DIR}/lib" -name "*.jar" 2>/dev/null | tr '\n' ':')
    SERVLET_JAR=$(find /usr -name "servlet-api.jar" 2>/dev/null | head -1)
    [ -n "$SERVLET_JAR" ] && LIB_CP="${LIB_CP}${SERVLET_JAR}:"
    javac -cp "${LIB_CP}" -d "${WEBAPP}/WEB-INF/classes" "$JSRC" 2>/dev/null && log "BankingServlet compiled" || {
        warn "Java compilation failed - check javac output"
        cp -r "${SCRIPT_DIR}/java-app/src/main/java/com" "${WEBAPP}/WEB-INF/classes/" 2>/dev/null || true
    }
fi

id tomcat >/dev/null 2>&1 || useradd -r -d "${TOMCAT_DIR}" -s /bin/false tomcat
chown -R tomcat:tomcat "${TOMCAT_DIR}"; chmod -R 755 "${TOMCAT_DIR}"

JAVA_HOME=$(dirname "$(dirname "$(readlink -f "$(which java)")")" 2>/dev/null); [ -z "$JAVA_HOME" ] && JAVA_HOME="/usr/lib/jvm/default-java"; [ -z "$JAVA_HOME" ] && JAVA_HOME=$(dirname "$(dirname "$(find /usr/lib/jvm -name javac 2>/dev/null | head -1)")")
cat > /etc/systemd/system/tomcat.service << TCSVC
[Unit]
Description=Apache Tomcat 9
After=network.target
[Service]
Type=forking
User=tomcat
Group=tomcat
Environment="JAVA_HOME=${JAVA_HOME}"
Environment="CATALINA_HOME=${TOMCAT_DIR}"
ExecStart=${TOMCAT_DIR}/bin/startup.sh
ExecStop=${TOMCAT_DIR}/bin/shutdown.sh
Restart=on-failure
[Install]
WantedBy=multi-user.target
TCSVC
chmod +x "${TOMCAT_DIR}/bin/"*.sh 2>/dev/null || true
systemctl daemon-reload; systemctl enable tomcat 2>/dev/null

# ── 7. WORDPRESS ──
log "Installing WordPress..."
wget -q https://wordpress.org/latest.tar.gz -O /tmp/wordpress.tar.gz 2>/dev/null
if [ -s /tmp/wordpress.tar.gz ]; then
    mkdir -p "${APP_DIR}/wordpress"
    tar -xzf /tmp/wordpress.tar.gz -C "${APP_DIR}/wordpress" --strip-components=1; rm /tmp/wordpress.tar.gz
    [ -f "${APP_DIR}/wordpress/wp-config-sample.php" ] && {
        cp "${APP_DIR}/wordpress/wp-config-sample.php" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/database_name_here/wordpress_db/" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/username_here/${MYSQL_APP_USER}/" "${APP_DIR}/wordpress/wp-config.php"
        sed -i "s/password_here/${MYSQL_APP_PASS}/" "${APP_DIR}/wordpress/wp-config.php"
    }
    [ -d "${SCRIPT_DIR}/wordpress-plugin" ] && {
        mkdir -p "${APP_DIR}/wordpress/wp-content/plugins/developer-flavor/developer-flavor-hash-form/"
        cp "${SCRIPT_DIR}/wordpress-plugin/"* "${APP_DIR}/wordpress/wp-content/plugins/developer-flavor/developer-flavor-hash-form/"
    }
    chown -R www-data:www-data "${APP_DIR}/wordpress"; chmod -R 777 "${APP_DIR}/wordpress/wp-content" 2>/dev/null
    log "WordPress installed"
else
    warn "WordPress download failed"
fi

# ── 8. SSH ──
log "Configuring SSH..."
mkdir -p /run/sshd
cat > /etc/ssh/sshd_config << 'SSH'
Port 22
ListenAddress 0.0.0.0
PasswordAuthentication yes
PermitEmptyPasswords no
PermitRootLogin yes
MaxAuthTries 100
LoginGraceTime 120
Banner /etc/ssh/banner
X11Forwarding yes
AllowTcpForwarding yes
GatewayPorts yes
Ciphers aes128-ctr,aes192-ctr,aes256-ctr,aes128-cbc,3des-cbc
MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512
LogLevel VERBOSE
UsePAM yes
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
SSH

cat > /etc/ssh/banner << 'BAN'
************************************************************
*         INTERNAL BANKING SYSTEM - AUTHORIZED ONLY        *
*   Banking Portal Server v2.4.1 - Ubuntu 22.04 LTS       *
*   Unauthorized access is strictly prohibited             *
************************************************************
BAN
[ ! -f /etc/ssh/ssh_host_rsa_key ] && ssh-keygen -A 2>/dev/null

# ── 9. USERS + PRIVESC ──
log "Creating users and priv-esc paths..."
id lowpriv >/dev/null 2>&1 || useradd -m -s /bin/bash lowpriv; echo "lowpriv:lowpriv123" | chpasswd
id ubicd4 >/dev/null 2>&1 || useradd -m -s /bin/bash ubicd4; echo "ubicd4:UbiCD4@2024" | chpasswd
echo "lowpriv ALL=(ALL) NOPASSWD: /usr/bin/find, /usr/bin/vim, /usr/bin/python3" > /etc/sudoers.d/lowpriv
chmod 440 /etc/sudoers.d/lowpriv

cat > /home/lowpriv/pwn.sh << 'PW'
#!/bin/bash
find /tmp -type f -name "*.tmp" -mtime +7 -delete 2>/dev/null
echo "Cleanup completed at $(date)" >> /var/log/maintenance.log
PW
chown lowpriv:lowpriv /home/lowpriv/pwn.sh; chmod 777 /home/lowpriv/pwn.sh
echo "* * * * * root /home/lowpriv/pwn.sh" > /etc/cron.d/maintenance-job; chmod 644 /etc/cron.d/maintenance-job

# Compile SUID helper binary
if [ -f "${SCRIPT_DIR}/suid_helper.c" ]; then
    gcc -o /usr/local/bin/logviewer "${SCRIPT_DIR}/suid_helper.c"
    if [ $? -eq 0 ] && [ -f /usr/local/bin/logviewer ]; then
        chown root:root /usr/local/bin/logviewer
        chmod 4755 /usr/local/bin/logviewer
        log "SUID binary compiled and installed"
    else
        warn "gcc compilation failed — trying with explicit flags"
        gcc -o /usr/local/bin/logviewer "${SCRIPT_DIR}/suid_helper.c" -static 2>/dev/null ||         gcc -o /usr/local/bin/logviewer "${SCRIPT_DIR}/suid_helper.c" -lc 2>/dev/null
        if [ -f /usr/local/bin/logviewer ]; then
            chown root:root /usr/local/bin/logviewer
            chmod 4755 /usr/local/bin/logviewer
            log "SUID binary compiled (fallback)"
        else
            err "SUID binary compilation failed"
        fi
    fi
else
    err "suid_helper.c not found at ${SCRIPT_DIR}/suid_helper.c"
fi
[ -f /usr/bin/find ] && cp /usr/bin/find /usr/local/bin/find-util && chown root:root /usr/local/bin/find-util && chmod 4755 /usr/local/bin/find-util

# ── 10. WEAKEN OS ──
log "Weakening OS security..."
echo 0 > /proc/sys/kernel/randomize_va_space 2>/dev/null
grep -q "kernel.randomize_va_space" /etc/sysctl.conf || echo "kernel.randomize_va_space = 0" >> /etc/sysctl.conf
sysctl -p 2>/dev/null || true
systemctl stop apparmor 2>/dev/null; systemctl disable apparmor 2>/dev/null
ufw disable 2>/dev/null || true
iptables -F 2>/dev/null; iptables -P INPUT ACCEPT 2>/dev/null; iptables -P FORWARD ACCEPT 2>/dev/null; iptables -P OUTPUT ACCEPT 2>/dev/null

# ── 11. START SERVICES ──
log "Starting all services..."
systemctl restart mysql 2>/dev/null; sleep 2
systemctl restart apache2 2>/dev/null
systemctl start tomcat 2>/dev/null
systemctl restart cron 2>/dev/null
systemctl enable ssh 2>/dev/null; systemctl enable sshd 2>/dev/null
systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null
sleep 3

# ── 12. VERIFY ──
# Wait for all services to be fully ready before verifying
log "Waiting for services to stabilize..."
sleep 5
# Extra wait for Apache/PHP to be ready
for i in $(seq 1 15); do
    curl -so /dev/null --connect-timeout 2 "http://localhost/" 2>/dev/null && break
    sleep 2
done

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Setup Complete — Verification${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
chk() { local c=$(curl -so /dev/null -w "%{http_code}" --connect-timeout 5 "$1" 2>/dev/null); [[ "$c" =~ ^(200|301|302|401)$ ]] && echo -e "  ${GREEN}[✓]${NC} $2" || echo -e "  ${RED}[✗]${NC} $2 (HTTP ${c:-fail})"; }
chk "http://localhost/" "Banking Portal (80)"
chk "http://localhost:8888/" "Customer Support (8888)"
chk "http://localhost:8080/" "Tomcat (8080)"
chk "http://localhost/api/internal.php" "Internal API"
mysql -u root -p"${MYSQL_ROOT_PASS}" -e "SELECT 1" 2>/dev/null | grep -q 1 && echo -e "  ${GREEN}[✓]${NC} MySQL (3306)" || echo -e "  ${RED}[✗]${NC} MySQL (3306)"
ss -tlnp | grep -q ":22 " && echo -e "  ${GREEN}[✓]${NC} SSH (22)" || echo -e "  ${RED}[✗]${NC} SSH (22)"
[ -u /usr/local/bin/logviewer ] && echo -e "  ${GREEN}[✓]${NC} SUID logviewer" || echo -e "  ${RED}[✗]${NC} SUID logviewer"

IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${RED}⚠  INTENTIONALLY VULNERABLE — ISOLATED NETWORKS ONLY ⚠${NC}"
echo ""
echo -e "${GREEN}Access:${NC}"
echo "  Portal:    http://${IP}/"
echo "  Support:   http://${IP}:8888/"
echo "  Tomcat:    http://${IP}:8080/manager/ (admin/admin)"
echo "  SSH:       ssh lowpriv@${IP} (lowpriv123)"
echo "  Web login: admin / Admin@123"
echo ""
log "Done"
