<div class="footer">
    &copy; 2024 Union Bank of India. All Rights Reserved. | 
    <a href="#">Privacy Policy</a> | <a href="#">Disclaimer</a> | 
    Powered by UBI-IT Division | Server: <?php echo gethostname(); ?>
</div>
