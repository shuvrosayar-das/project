<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$loans = $db->query("SELECT * FROM loans ORDER BY id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loans - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header"><h2>Loan Management</h2><p>Active loans and processing queue</p></div>
            <div class="content-card">
                <div class="card-header"><h3>Active Loans</h3></div>
                <table class="data-table">
                    <thead><tr><th>Loan ID</th><th>Borrower</th><th>Type</th><th>Principal</th><th>Rate</th><th>EMI</th><th>Outstanding</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php while($loan = $loans->fetch_assoc()): ?>
                    <tr>
                        <td><code><?php echo $loan['loan_id']; ?></code></td>
                        <td><?php echo htmlspecialchars($loan['borrower_name']); ?></td>
                        <td><?php echo ucfirst($loan['loan_type']); ?></td>
                        <td class="amount">&#8377;<?php echo number_format($loan['principal_amount'], 2); ?></td>
                        <td><?php echo $loan['interest_rate']; ?>%</td>
                        <td>&#8377;<?php echo number_format($loan['emi_amount'], 2); ?></td>
                        <td class="amount">&#8377;<?php echo number_format($loan['outstanding_balance'], 2); ?></td>
                        <td><span class="badge badge-<?php echo $loan['status']; ?>"><?php echo ucfirst($loan['status']); ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
<?php $db->close(); ?>
