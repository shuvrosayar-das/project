<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$user = $db->query("SELECT * FROM users WHERE id={$_SESSION['user_id']}")->fetch_assoc();
$recent_txns = $db->query("SELECT * FROM transactions ORDER BY transaction_date DESC LIMIT 5");
$account_count = $db->query("SELECT COUNT(*) as cnt FROM accounts")->fetch_assoc()['cnt'];
$loan_count = $db->query("SELECT COUNT(*) as cnt FROM loans WHERE status='active'")->fetch_assoc()['cnt'];
$pending_txns = $db->query("SELECT COUNT(*) as cnt FROM transactions WHERE status='pending'")->fetch_assoc()['cnt'];
$total_balance = $db->query("SELECT SUM(balance) as total FROM accounts WHERE balance > 0")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-panel">
            <div class="page-header">
                <h2>Dashboard</h2>
                <p>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?> | Last Login: <?php echo $user['last_login']; ?></p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#003580;">&#8377;</div>
                    <div class="stat-info">
                        <span class="stat-value">&#8377;<?php echo number_format($total_balance, 2); ?></span>
                        <span class="stat-label">Total Deposits</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#E31837;">&#128202;</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $account_count; ?></span>
                        <span class="stat-label">Active Accounts</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#003580;">&#128203;</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $loan_count; ?></span>
                        <span class="stat-label">Active Loans</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background:#B8102A;">&#8987;</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $pending_txns; ?></span>
                        <span class="stat-label">Pending Transfers</span>
                    </div>
                </div>
            </div>
            
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-header">
                        <h3>Recent Transactions</h3>
                        <a href="transactions.php" class="btn-link">View All →92</a>
                    </div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>TXN ID</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($txn = $recent_txns->fetch_assoc()): ?>
                            <tr>
                                <td><code><?php echo $txn['transaction_id']; ?></code></td>
                                <td><?php echo $txn['from_account'] ?: '-'; ?></td>
                                <td><?php echo $txn['to_account'] ?: '-'; ?></td>
                                <td class="amount">&#8377;<?php echo number_format($txn['amount'], 2); ?></td>
                                <td><span class="badge badge-<?php echo $txn['status']; ?>"><?php echo ucfirst($txn['status']); ?></span></td>
                                <td><?php echo date('d-M-Y H:i', strtotime($txn['transaction_date'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="content-card">
                    <div class="card-header">
                        <h3>Internal Messages</h3>
                        <a href="messages.php" class="btn-link">Inbox →92</a>
                    </div>
                    <?php
                    $msgs = $db->query("SELECT * FROM messages WHERE recipient='{$_SESSION['username']}' ORDER BY created_at DESC LIMIT 5");
                    while($msg = $msgs->fetch_assoc()):
                    ?>
                    <div class="message-item <?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                        <div class="msg-sender"><?php echo $msg['sender']; ?></div>
                        <div class="msg-subject"><?php echo $msg['subject']; ?></div>
                        <!-- VULNERABLE: Body rendered without escaping - Stored XSS -->
                        <div class="msg-preview"><?php echo $msg['body']; ?></div>
                        <div class="msg-date"><?php echo date('d-M H:i', strtotime($msg['created_at'])); ?></div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            
            <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'manager' || $_SESSION['role'] === 'cashier'): ?>
            <div class="content-card">
                <div class="card-header">
                    <h3>Audit Log (Recent)</h3>
                    <a href="audit.php" class="btn-link">Full Log →92</a>
                </div>
                <table class="data-table">
                    <thead>
                        <tr><th>Time</th><th>User</th><th>Action</th><th>Details</th><th>IP</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $logs = $db->query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 8");
                        while($log = $logs->fetch_assoc()):
                        ?>
                        <tr>
                            <td><?php echo date('d-M H:i', strtotime($log['timestamp'])); ?></td>
                            <td><?php echo $log['user']; ?></td>
                            <td><code><?php echo $log['action']; ?></code></td>
                            <td><?php echo $log['details']; ?></td>
                            <td><code><?php echo $log['ip_address']; ?></code></td>
                            <td><span class="badge badge-<?php echo $log['status']; ?>"><?php echo $log['status']; ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </main>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script>
    // Fetch user details via API (generates Burp Suite capturable traffic)
    fetch('/api/accounts.php?api=get_user&acc_no=<?php echo $user['id']; ?>')
        .then(r => r.json())
        .then(d => console.log('API response:', d))
        .catch(e => {});
    </script>
</body>
</html>
<?php $db->close(); ?>
