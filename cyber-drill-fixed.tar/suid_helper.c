#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <logfile>\n", argv[0]);
        return 1;
    }
    // Intended to read log files, but executes with elevated privileges
    setuid(0);
    setgid(0);
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "/bin/cat %s", argv[1]);
    system(cmd);
    return 0;
}
