#!/bin/bash
for i in $(seq 1 30); do
    mysqladmin -u bankadmin -p'B@nkAdm1n_2024' ping --silent 2>/dev/null && break
    mysqladmin ping --silent 2>/dev/null && break
    sleep 1
done
source /etc/apache2/envvars
exec /usr/sbin/apache2 -D FOREGROUND
