<?php
// Union Bank of India - Customer Support Portal
// Runs on port 8888 via PHP-CGI (intentionally vulnerable to CVE-2024-4577)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Union Bank of India - Customer Support Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Noto Sans',sans-serif; background:#F2F4F7; color:#1a1a2e; min-height:100vh; }
        .top-strip { height:4px; display:flex; }
        .top-strip span:nth-child(1) { flex:1; background:#003580; }
        .top-strip span:nth-child(2) { flex:1; background:#fff; }
        .top-strip span:nth-child(3) { flex:1; background:#E31837; }
        .header { background:linear-gradient(180deg,#003580,#002050); padding:18px 40px; display:flex; justify-content:space-between; align-items:center; }
        .header .brand { display:flex; align-items:center; gap:14px; color:#fff; }
        .header .brand .logo { width:44px; height:44px; background:linear-gradient(135deg,#E31837,#B8102A); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:700; }
        .header .brand h1 { font-size:20px; font-weight:700; }
        .header .brand p { font-size:10px; color:rgba(255,255,255,0.7); text-transform:uppercase; letter-spacing:1px; }
        .header .info { color:rgba(255,255,255,0.8); font-size:12px; }
        .container { max-width:900px; margin:40px auto; padding:0 20px; }
        .card { background:#fff; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #dde3ed; overflow:hidden; margin-bottom:24px; }
        .card-header { background:#f8f9fc; padding:16px 24px; border-bottom:1px solid #dde3ed; }
        .card-header h2 { font-size:16px; color:#003580; }
        .card-body { padding:24px; }
        .form-group { margin-bottom:16px; }
        .form-group label { display:block; font-size:13px; font-weight:600; color:#003580; margin-bottom:6px; }
        .form-group input,.form-group textarea,.form-group select { width:100%; padding:10px 14px; border:2px solid #dde3ed; border-radius:8px; font-size:13px; font-family:inherit; background:#f8f9fc; }
        .form-group input:focus,.form-group textarea:focus { outline:none; border-color:#003580; background:#fff; }
        .btn { padding:11px 28px; background:linear-gradient(135deg,#E31837,#B8102A); color:#fff; border:none; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; }
        .btn:hover { background:linear-gradient(135deg,#cc1430,#a00d22); }
        .result { background:#e3f0ff; border-left:3px solid #003580; padding:14px 18px; border-radius:6px; margin-top:16px; font-size:13px; }
        .result pre { white-space:pre-wrap; font-family:Consolas,monospace; font-size:12px; margin-top:8px; background:#f0f2f5; padding:10px; border-radius:4px; }
        .footer { text-align:center; padding:20px; font-size:11px; color:#5a6270; }
        .footer a { color:#003580; text-decoration:none; }
        .nav { display:flex; gap:20px; padding:10px 40px; background:#002050; }
        .nav a { color:#b8cce8; text-decoration:none; font-size:13px; font-weight:500; }
        .nav a:hover { color:#fff; }
        .server-info { background:#fff0f2; border-left:3px solid #E31837; padding:10px 14px; border-radius:4px; font-size:11px; color:#5a6270; margin-top:20px; }
    </style>
</head>
<body>
    <div class="top-strip"><span></span><span></span><span></span></div>
    <div class="header">
        <div class="brand">
            <div class="logo">&#9733;</div>
            <div>
                <h1>Union Bank of India</h1>
                <p>Customer Support Portal</p>
            </div>
        </div>
        <div class="info">Support Helpline: 1800-222-244 (Toll Free)</div>
    </div>
    <div class="nav">
        <a href="index.php">Home</a>
        <a href="index.php?page=faq">FAQ</a>
        <a href="index.php?page=status">Service Status</a>
        <a href="index.php?page=contact">Contact Us</a>
    </div>
    <div class="container">
        <?php
        $page = $_GET['page'] ?? 'home';
        
        switch($page) {
            case 'status':
                echo '<div class="card"><div class="card-header"><h2>Service Status Check</h2></div><div class="card-body">';
                echo '<p>All core banking services are operational.</p>';
                echo '<div class="server-info">';
                echo '<strong>Server:</strong> ' . php_uname() . '<br>';
                echo '<strong>PHP Version:</strong> ' . phpversion() . '<br>';
                echo '<strong>SAPI:</strong> ' . php_sapi_name() . '<br>';
                echo '<strong>Server Software:</strong> ' . ($_SERVER['SERVER_SOFTWARE'] ?? 'N/A') . '<br>';
                // VULNERABLE: Information disclosure
                echo '<strong>Document Root:</strong> ' . ($_SERVER['DOCUMENT_ROOT'] ?? 'N/A') . '<br>';
                echo '<strong>Script:</strong> ' . ($_SERVER['SCRIPT_FILENAME'] ?? 'N/A');
                echo '</div></div></div>';
                break;
                
            case 'faq':
                echo '<div class="card"><div class="card-header"><h2>Frequently Asked Questions</h2></div><div class="card-body">';
                echo '<p><strong>Q: How do I reset my net banking password?</strong><br>A: Visit your nearest branch with valid ID proof.</p><br>';
                echo '<p><strong>Q: What are the NEFT/RTGS timings?</strong><br>A: NEFT: 24x7, RTGS: 7:00 AM to 6:00 PM on business days.</p><br>';
                echo '<p><strong>Q: How to register for mobile banking?</strong><br>A: Download U-Mobile app and register with your account number and debit card.</p>';
                echo '</div></div>';
                break;
                
            case 'contact':
                echo '<div class="card"><div class="card-header"><h2>Contact Us</h2></div><div class="card-body">';
                echo '<p><strong>Toll Free:</strong> 1800-222-244 / 1800-208-2244</p>';
                echo '<p><strong>Email:</strong> customercare@unionbank.internal</p>';
                echo '<p><strong>Head Office:</strong> Union Bank Bhavan, 239 Vidhan Bhavan Marg, Nariman Point, Mumbai - 400021</p>';
                echo '</div></div>';
                break;
                
            default:
                // Home page with complaint form
                $complaint = '';
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $name = $_POST['name'] ?? '';
                    $account = $_POST['account'] ?? '';
                    $issue = $_POST['issue'] ?? '';
                    // VULNERABLE: No CSRF, information in response
                    $complaint = "Complaint registered successfully. Reference: CMP-" . date('YmdHis') . "-" . rand(100,999);
                    $complaint .= "\nName: $name\nAccount: $account\nIssue: $issue";
                }
                echo '<div class="card"><div class="card-header"><h2>Register a Complaint</h2></div><div class="card-body">';
                echo '<form method="POST">';
                echo '<div class="form-group"><label>Full Name</label><input type="text" name="name" placeholder="Enter your full name" required></div>';
                echo '<div class="form-group"><label>Account Number</label><input type="text" name="account" placeholder="Enter account number"></div>';
                echo '<div class="form-group"><label>Issue Category</label><select name="category"><option>Net Banking</option><option>Mobile Banking</option><option>ATM/Debit Card</option><option>Credit Card</option><option>Loan</option><option>Other</option></select></div>';
                echo '<div class="form-group"><label>Describe Your Issue</label><textarea name="issue" rows="4" placeholder="Please describe your issue in detail..." required></textarea></div>';
                echo '<button type="submit" class="btn">Submit Complaint</button>';
                echo '</form>';
                if ($complaint) {
                    echo '<div class="result"><strong>&#10004; Complaint Registered</strong><pre>' . htmlspecialchars($complaint) . '</pre></div>';
                }
                echo '</div></div>';
                break;
        }
        ?>
        <div class="server-info">
            <strong>Portal Version:</strong> 3.2.1-cgi | 
            <strong>PHP SAPI:</strong> <?php echo php_sapi_name(); ?> | 
            <strong>Server:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Apache'; ?>
        </div>
    </div>
    <div class="footer">
        &copy; 2024 Union Bank of India. All Rights Reserved. | 
        <a href="#">Terms</a> | <a href="#">Privacy</a> | 
        Powered by UBI-IT Division
    </div>
</body>
</html>
