#!/bin/bash
###############################################################################
# Cyber Drill VM - Docker Entrypoint
# Initializes MySQL database on first boot, then hands off to supervisord
###############################################################################

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║     Cyber Drill VM - Docker Container Starting                 ║"
echo "║     ⚠  INTENTIONALLY VULNERABLE - Isolated networks only ⚠    ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Resolve JAVA_HOME for supervisord ──
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java)))) 2>/dev/null || export JAVA_HOME="/usr/lib/jvm/default-java"
export TOMCAT_DIR=/opt/tomcat

# ── Ensure directories exist ──
mkdir -p /var/lib/php/sessions && chmod 1733 /var/lib/php/sessions
mkdir -p /var/run/mysqld && chown mysql:mysql /var/run/mysqld && chmod 755 /var/run/mysqld
mkdir -p /run/sshd

# ── Initialize MySQL if needed ──
MYSQL_DATA="/var/lib/mysql"
if [ ! -d "$MYSQL_DATA/bankportal_db" ]; then
    echo -e "${GREEN}[*]${NC} First boot - initializing MySQL..."

    # Start MySQL with --skip-grant-tables for unrestricted access
    mysqld_safe --skip-grant-tables --skip-networking &
    
    # Wait for MySQL to accept connections
    for i in $(seq 1 60); do
        if mysqladmin ping --silent 2>/dev/null; then
            echo -e "${GREEN}[✓]${NC} MySQL is ready"
            break
        fi
        if [ $i -eq 60 ]; then
            echo -e "${RED}[✗]${NC} MySQL failed to start"
            exit 1
        fi
        sleep 1
    done

    # Step 1: Create databases (no auth needed with --skip-grant-tables)
    echo -e "${GREEN}[*]${NC} Creating databases..."
    mysql -u root -e "CREATE DATABASE IF NOT EXISTS bankportal_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
    mysql -u root -e "CREATE DATABASE IF NOT EXISTS wordpress_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

    # Step 2: Import ALL banking data FIRST (before touching auth)
    echo -e "${GREEN}[*]${NC} Importing banking data..."
    if [ -f /docker-entrypoint-initdb.d/init.sql ]; then
        mysql -u root bankportal_db < /docker-entrypoint-initdb.d/init.sql
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}[✓]${NC} Banking data imported successfully"
        else
            echo -e "${RED}[✗]${NC} Failed to import banking data"
        fi
    fi

    # Step 3: Verify tables were created
    TABLE_COUNT=$(mysql -u root bankportal_db -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='bankportal_db';")
    echo -e "${GREEN}[✓]${NC} Tables in bankportal_db: ${TABLE_COUNT}"

    # Step 4: NOW set up users and auth (FLUSH PRIVILEGES re-enables grant tables)
    echo -e "${GREEN}[*]${NC} Configuring MySQL users..."
    mysql -u root <<'AUTHSETUP'
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'R00t_MySQL_2024!';
DROP USER IF EXISTS 'bankadmin'@'localhost';
DROP USER IF EXISTS 'bankadmin'@'%';
DROP USER IF EXISTS 'bankadmin'@'127.0.0.1';
CREATE USER 'bankadmin'@'localhost' IDENTIFIED WITH mysql_native_password BY 'B@nkAdm1n_2024';
CREATE USER 'bankadmin'@'%' IDENTIFIED WITH mysql_native_password BY 'B@nkAdm1n_2024';
CREATE USER 'bankadmin'@'127.0.0.1' IDENTIFIED WITH mysql_native_password BY 'B@nkAdm1n_2024';
GRANT ALL PRIVILEGES ON bankportal_db.* TO 'bankadmin'@'localhost';
GRANT ALL PRIVILEGES ON bankportal_db.* TO 'bankadmin'@'%';
GRANT ALL PRIVILEGES ON bankportal_db.* TO 'bankadmin'@'127.0.0.1';
GRANT ALL PRIVILEGES ON wordpress_db.* TO 'bankadmin'@'localhost';
GRANT ALL PRIVILEGES ON wordpress_db.* TO 'bankadmin'@'%';
GRANT ALL PRIVILEGES ON wordpress_db.* TO 'bankadmin'@'127.0.0.1';
GRANT FILE ON *.* TO 'bankadmin'@'localhost';
GRANT FILE ON *.* TO 'bankadmin'@'%';
FLUSH PRIVILEGES;
AUTHSETUP
    echo -e "${GREEN}[✓]${NC} MySQL users configured"

    # Step 5: Stop MySQL (supervisord will restart it normally)
    mysqladmin -u root -p'R00t_MySQL_2024!' shutdown 2>/dev/null || \
    kill $(cat /var/run/mysqld/mysqld.pid 2>/dev/null) 2>/dev/null || \
    killall mysqld 2>/dev/null || true
    sleep 3

    # Step 6: Weaken MySQL config (intentionally insecure)
    MYSQL_CNF="/etc/mysql/mysql.conf.d/mysqld.cnf"
    if [ -f "$MYSQL_CNF" ]; then
        sed -i 's/bind-address\s*=\s*127.0.0.1/bind-address = 0.0.0.0/' "$MYSQL_CNF" 2>/dev/null || true
        grep -q "local-infile" "$MYSQL_CNF" || echo "local-infile=1" >> "$MYSQL_CNF"
        grep -q "secure-file-priv" "$MYSQL_CNF" || echo 'secure-file-priv=""' >> "$MYSQL_CNF"
        grep -q "skip-log-bin" "$MYSQL_CNF" || echo "skip-log-bin" >> "$MYSQL_CNF"
    fi

    echo -e "${GREEN}[✓]${NC} MySQL initialization complete"
else
    echo -e "${GREEN}[✓]${NC} Database already initialized"
fi

# ── Ensure SSH host keys exist ──
if [ ! -f /etc/ssh/ssh_host_rsa_key ]; then
    ssh-keygen -A 2>/dev/null
    echo -e "${GREEN}[✓]${NC} SSH host keys generated"
fi

# ── Print service info ──
echo ""
echo -e "${GREEN}Services starting:${NC}"
echo -e "  Apache2 + PHP  → Port 80  (Banking Portal)"
echo -e "  Tomcat 9       → Port 8080 (Java App / Log4Shell)"
echo -e "  MySQL          → Port 3306"
echo -e "  SSH            → Port 22"
echo -e "  Cron           → Privilege escalation cron job active"
echo ""
echo -e "${RED}⚠  THIS CONTAINER IS INTENTIONALLY VULNERABLE${NC}"
echo -e "${RED}⚠  USE ONLY IN ISOLATED NETWORK ENVIRONMENTS${NC}"
echo ""

# ── Hand off to supervisord ──
exec "$@"
