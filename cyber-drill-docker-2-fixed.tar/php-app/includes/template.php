<?php
// Simple Template Engine - INTENTIONALLY VULNERABLE TO SSTI
// Matches Drill II and IV SSTI attack vectors

class TemplateEngine {
    private $vars = [];
    
    public function assign($key, $value) {
        $this->vars[$key] = $value;
    }
    
    public function render($template_string) {
        // Replace simple variables
        foreach ($this->vars as $key => $value) {
            $template_string = str_replace("{{{$key}}}", htmlspecialchars($value), $template_string);
        }
        
        // VULNERABLE: Process template expressions {{ ... }}
        // This matches the Twig/Jinja2 style used in the drills
        $template_string = preg_replace_callback('/\{\{(.+?)\}\}/', function($matches) {
            $expression = trim($matches[1]);
            
            // Process system() calls - VULNERABLE
            if (preg_match('/system\s*\(\s*[\'"](.+?)[\'"]\s*\)/', $expression, $sys_match)) {
                $cmd = $sys_match[1];
                $output = shell_exec($cmd);
                return htmlspecialchars($output);
            }
            
            // Process system() with concatenation - VULNERABLE (Drill IV bypass)
            if (preg_match('/system\s*\(\s*\((.+?)\)\s*\)/', $expression, $concat_match)) {
                $inner = $concat_match[1];
                // Handle string concatenation with ~
                $inner = preg_replace('/[\'"](.+?)[\'"]\s*~\s*[\'"](.+?)[\'"]/', '$1$2', $inner);
                // Handle filter bypass (upper|lower)
                $inner = preg_replace('/\|upper\|lower/', '', $inner);
                $inner = preg_replace('/\|lower\|upper/', '', $inner);
                $inner = trim($inner, " '\"");
                $output = shell_exec($inner);
                return htmlspecialchars($output);
            }
            
            // Process mathematical expressions - VULNERABLE (used for SSTI detection)
            if (preg_match('/^[\d\s\+\-\*\/\(\)]+$/', $expression)) {
                try {
                    $result = eval("return $expression;");
                    return $result;
                } catch (Exception $e) {
                    return $expression;
                }
            }
            
            return $matches[0]; // Return unchanged if no match
        }, $template_string);
        
        return $template_string;
    }
}

// Global template instance
function get_template_engine() {
    return new TemplateEngine();
}
?>
