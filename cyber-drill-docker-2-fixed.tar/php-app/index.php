<?php
require_once __DIR__ . '/includes/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($username) && !empty($password)) {
        $db = get_db();
        $password_hash = md5($password);
        
        // VULNERABLE: SQL Injection in login - but client-side validation prevents direct input
        // Bypassing via Burp Suite intercept is required (matching Drill I approach)
        $query = "SELECT * FROM users WHERE username='$username' AND password='$password_hash'";
        $result = $db->query($query);
        
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['full_name'] = $user['full_name'];
            
            // Log successful login
            $ip = $_SERVER['REMOTE_ADDR'];
            $ua = $db->real_escape_string($_SERVER['HTTP_USER_AGENT']);
            $db->query("INSERT INTO audit_logs (user, action, details, ip_address, user_agent, status) 
                        VALUES ('{$user['username']}', 'LOGIN', 'Successful login', '$ip', '$ua', 'success')");
            
            // Update last login - NO account lockout (VULNERABLE to credential stuffing)
            $db->query("UPDATE users SET last_login=NOW(), login_attempts=0 WHERE id={$user['id']}");
            
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Invalid credentials";
            // VULNERABLE: Does NOT increment lockout counter (credential stuffing enabled)
            $ip = $_SERVER['REMOTE_ADDR'];
            $ua = $db->real_escape_string($_SERVER['HTTP_USER_AGENT'] ?? '');
            $safe_user = $db->real_escape_string($username);
            $db->query("INSERT INTO audit_logs (user, action, details, ip_address, user_agent, status) 
                        VALUES ('$safe_user', 'LOGIN', 'Failed login attempt', '$ip', '$ua', 'failure')");
        }
        $db->close();
    } else {
        $error = "Please enter both username and password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Union Bank of India - Internal Banking Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Noto Sans', sans-serif; 
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Top Header Bar - Union Bank inspired deep blue */
        .top-bar {
            background: linear-gradient(135deg, #003580 0%, #002050 100%);
            color: white;
            padding: 8px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
        }
        .top-bar a { color: #ffffff; text-decoration: none; }
        .top-bar .toll-free { display: flex; gap: 15px; align-items: center; }
        .top-bar .toll-free span { color: #ffffff; font-weight: 600; }
        
        /* Main Header */
        .header {
            background: linear-gradient(180deg, #003580 0%, #002050 100%);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(0,48,135,0.3);
        }
        .header .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .header .logo-icon {
            width: 55px;
            height: 55px;
            background: linear-gradient(135deg, #E31837 0%, #B8102A 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(227,24,55,0.4);
        }
        .header .bank-name {
            color: white;
        }
        .header .bank-name h1 {
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .header .bank-name p {
            font-size: 11px;
            color: #E31837;
            font-weight: 500;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .header .tricolor {
            height: 4px;
            display: flex;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
        }
        .header .tricolor span:nth-child(1) { flex: 1; background: #003580; }
        .header .tricolor span:nth-child(2) { flex: 1; background: #ffffff; }
        .header .tricolor span:nth-child(3) { flex: 1; background: #E31837; }
        .header { position: relative; }
        
        /* Navigation */
        .nav-bar {
            background: #004399;
            padding: 0 30px;
            display: flex;
            gap: 0;
            border-bottom: 3px solid #E31837;
        }
        .nav-bar a {
            color: #b8cce8;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s;
            border-bottom: 3px solid transparent;
            margin-bottom: -3px;
        }
        .nav-bar a:hover, .nav-bar a.active {
            color: white;
            background: rgba(227,24,55,0.1);
            border-bottom-color: #E31837;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 30px;
            background: linear-gradient(135deg, #f0f2f5 0%, #e8ecf2 50%, #f5f0e8 100%);
        }
        
        /* Login Box */
        .login-container {
            display: flex;
            max-width: 950px;
            width: 100%;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,48,135,0.12);
            overflow: hidden;
        }
        .login-info {
            flex: 1;
            background: linear-gradient(135deg, #003580 0%, #001a4d 100%);
            padding: 50px 40px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-info h2 {
            font-size: 26px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        .login-info p {
            font-size: 14px;
            line-height: 1.7;
            color: #b8cce8;
            margin-bottom: 30px;
        }
        .login-info .features {
            list-style: none;
            padding: 0;
        }
        .login-info .features li {
            padding: 8px 0;
            font-size: 13px;
            color: #d1dff0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .login-info .features li::before {
            content: '✦26';
            color: #E31837;
            font-size: 12px;
        }
        .login-info .security-badge {
            margin-top: 30px;
            padding: 12px 16px;
            background: rgba(227,24,55,0.1);
            border-left: 3px solid #E31837;
            border-radius: 0 8px 8px 0;
            font-size: 11px;
            color: #E31837;
        }
        
        .login-form {
            flex: 1;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-form h3 {
            color: #003580;
            font-size: 22px;
            margin-bottom: 5px;
        }
        .login-form .subtitle {
            color: #666;
            font-size: 13px;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            color: #003580;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #dde3ed;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
            background: #f8f9fc;
        }
        .form-group input:focus {
            outline: none;
            border-color: #003580;
            background: white;
            box-shadow: 0 0 0 3px rgba(0,48,135,0.1);
        }
        .btn-login {
            width: 100%;
            padding: 13px;
            background: linear-gradient(135deg, #E31837 0%, #B8102A 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(227,24,55,0.3);
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #ff8800 0%, #e65c00 100%);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(227,24,55,0.4);
        }
        .error-msg {
            background: #fff0f0;
            color: #cc0000;
            padding: 10px 16px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 15px;
            border-left: 3px solid #cc0000;
        }
        .form-links {
            margin-top: 20px;
            text-align: center;
        }
        .form-links a {
            color: #003580;
            font-size: 12px;
            text-decoration: none;
        }
        .form-links a:hover {
            color: #B8102A;
        }
        
        /* Footer */
        .footer {
            background: #001a4d;
            color: #7a8eb5;
            padding: 15px 30px;
            text-align: center;
            font-size: 11px;
        }
        .footer a { color: #E31837; text-decoration: none; }
        
        /* Scrolling Notice */
        .notice-bar {
            background: #fff8e6;
            border-bottom: 1px solid #ffe0a0;
            padding: 8px 30px;
            font-size: 12px;
            color: #8b6914;
            overflow: hidden;
        }
        .notice-bar marquee { color: rgba(255,255,255,0.8); font-weight: 500; }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="toll-free">
            <span>☎0e</span> Toll Free: <span>1800 XXX XXXX</span> | <span>1800 XXX XXXX</span>
        </div>
        <div>
            Internal Portal v2.4.1 | <a href="#">User Guide</a> | <a href="#">Contact IT</a>
        </div>
    </div>
    
    <div class="header">
        <div class="logo-section">
            <div class="logo-icon"><div class="logo-icon">UB</div>#9733;</div>
            <div class="bank-name">
                <h1>Union Bank of India</h1>
                <p>Internal Banking Operations Portal</p>
            </div>
        </div>
        <div class="tricolor">
            <span></span><span></span><span></span>
        </div>
    </div>
    
    <div class="nav-bar">
        <a href="index.php" class="active">Home</a>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="#">Downloads</a>
        <a href="#">Contact IT Support</a>
    </div>
    
    <div class="notice-bar">
        <marquee behavior="scroll" direction="left" scrollamount="3">
            ⚠a0 NOTICE: All employees must complete annual cybersecurity awareness training by December 31, 2024. 
            Contact IT Security department for enrollment. | 
            System maintenance scheduled for Sunday 00:00-04:00 IST. | 
            New loan processing module v3.2 deployed - refer to internal circular IC/2024/089
        </marquee>
    </div>
    
    <div class="main-content">
        <div class="login-container">
            <div class="login-info">
                <h2>Welcome to the Internal Banking Portal</h2>
                <p>Secure access to banking operations, account management, fund transfers, and loan processing systems.</p>
                <ul class="features">
                    <li>Account Management & Enquiry</li>
                    <li>Internal Fund Transfer Processing</li>
                    <li>Loan Origination & Approval</li>
                    <li>Transaction Monitoring & Reports</li>
                    <li>Branch Operations Dashboard</li>
                    <li>Audit Trail & Compliance</li>
                </ul>
                <div class="security-badge">
                    🔒12 This system is for authorized personnel only. All activities are monitored and logged.
                </div>
            </div>
            
            <div class="login-form">
                <h3>Sign In</h3>
                <p class="subtitle">Enter your employee credentials to access the portal</p>
                
                <?php if ($error): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="index.php" id="loginForm">
                    <div class="form-group">
                        <label>Employee ID / Username</label>
                        <input type="text" name="username" id="username" placeholder="Enter your employee ID" required
                               pattern="[a-zA-Z0-9_]+" title="Only letters, numbers and underscores allowed">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" class="btn-login">Sign In to Portal</button>
                </form>
                
                <div class="form-links">
                    <a href="#">Forgot Password?</a> &nbsp;|&nbsp; 
                    <a href="#">First Time Login?</a> &nbsp;|&nbsp;
                    <a href="#">Request Access</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        ©a9 2024 Union Bank of India. All Rights Reserved. | 
        <a href="#">Privacy Policy</a> | 
        <a href="#">Terms of Use</a> | 
        <a href="#">Disclaimer</a> | 
        Powered by UBI-IT Division
    </div>
    
    <script>
    // CLIENT-SIDE ONLY validation (can be bypassed via Burp Suite)
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        var username = document.getElementById('username').value;
        var blocked = /['";\\<>(){}|&$`!]/;
        if (blocked.test(username)) {
            e.preventDefault();
            alert('Invalid characters detected in username. Only alphanumeric characters and underscores are allowed.');
            return false;
        }
    });
    </script>
</body>
</html>
