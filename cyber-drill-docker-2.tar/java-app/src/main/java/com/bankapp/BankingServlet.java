package com.bankapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Intentionally vulnerable servlet for cyber drill exercises.
 *
 * NOTE: Do NOT "fix" the Log4Shell attack surface here.
 * This app intentionally logs user-controlled input directly.
 */
public class BankingServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger logger = LogManager.getLogger(BankingServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Intentionally log user-controlled input (Log4Shell surface)
        String query = safe(req.getParameter("query"));
        String action = safe(req.getParameter("action"));
        String term = safe(req.getParameter("term"));

        String userAgent = safe(req.getHeader("User-Agent"));
        String xForwardedFor = safe(req.getHeader("X-Forwarded-For"));
        String referer = safe(req.getHeader("Referer"));
        String acceptLanguage = safe(req.getHeader("Accept-Language"));

        logger.info("Banking App Request - Query: " + query);
        logger.info("Action: " + action);
        logger.info("Search term: " + term);
        logger.info("User-Agent: " + userAgent);
        logger.info("X-Forwarded-For: " + xForwardedFor);
        logger.info("Referer: " + referer);
        logger.info("Accept-Language: " + acceptLanguage);

        resp.setContentType("text/html; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<html><head><title>Java Banking App</title></head><body>");
        out.println("<h2>Java Banking App (Tomcat)</h2>");
        out.println("<p>Status: OK</p>");
        out.println("<p>Try: <code>/?query=hello</code></p>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Intentionally log user-controlled input (Log4Shell surface)
        String username = safe(req.getParameter("username"));
        String beneficiary = safe(req.getParameter("beneficiary"));

        logger.info("Login attempt for user: " + username);
        logger.info("Transfer request - Beneficiary: " + beneficiary);

        resp.setContentType("text/plain; charset=UTF-8");
        resp.getWriter().println("OK");
    }

    private static String safe(String s) {
        return (s == null) ? "" : s;
    }
}
