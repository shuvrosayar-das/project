#!/bin/bash
for i in $(seq 1 30); do
    mysqladmin ping --silent 2>/dev/null && break
    sleep 1
done
source /etc/apache2/envvars
exec /usr/sbin/apache2 -D FOREGROUND
