<?php
require_once __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$db = get_db();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $file = $_FILES['document'];
    $upload_dir = __DIR__ . '/uploads/';
    
    // VULNERABLE: No proper file type validation
    // No magic byte check, no extension whitelist, no file content inspection
    // Matches CVE-2024-5084 Hash Form vulnerability pattern
    
    $filename = basename($file['name']);
    $target = $upload_dir . $filename;
    
    // Only client-side "validation" exists - easily bypassed
    $allowed_display = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'png'];
    
    if (move_uploaded_file($file['tmp_name'], $target)) {
        // Make uploaded file executable (for PHP webshells)
        chmod($target, 0755);
        
        $message = "File uploaded successfully: <a href='uploads/$filename' target='_blank'>$filename</a>";
        
        $ip = $_SERVER['REMOTE_ADDR'];
        $db->query("INSERT INTO audit_logs (user, action, details, ip_address, status) 
                    VALUES ('{$_SESSION['username']}', 'FILE_UPLOAD', 'Uploaded: $filename', '$ip', 'success')");
    } else {
        $error = "Upload failed. Error code: " . $file['error'];
    }
}

// List uploaded files
$uploads = [];
$upload_path = __DIR__ . '/uploads/';
if (is_dir($upload_path)) {
    $files = scandir($upload_path);
    foreach ($files as $f) {
        if ($f !== '.' && $f !== '..' && $f !== '.htaccess') {
            $uploads[] = [
                'name' => $f,
                'size' => filesize($upload_path . $f),
                'date' => date('d-M-Y H:i', filemtime($upload_path . $f)),
                'type' => pathinfo($f, PATHINFO_EXTENSION)
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload - Union Bank of India Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-panel">
            <div class="page-header">
                <h2>Document Upload</h2>
                <p>Upload KYC documents, loan papers, and branch circulars</p>
            </div>
            
            <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>
            
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-header"><h3>Upload Document</h3></div>
                    <div class="form-container">
                        <form method="POST" enctype="multipart/form-data" id="uploadForm">
                            <div class="form-group">
                                <label>Select File</label>
                                <input type="file" name="document" id="fileInput" required>
                                <small style="color:#666;font-size:11px;">Accepted: PDF, DOC, DOCX, XLS, XLSX, JPG, PNG (Max: 50MB)</small>
                            </div>
                            <button type="submit" class="btn-primary">Upload Document</button>
                        </form>
                    </div>
                </div>
                
                <div class="content-card">
                    <div class="card-header"><h3>Uploaded Files</h3></div>
                    <table class="data-table">
                        <thead><tr><th>Filename</th><th>Type</th><th>Size</th><th>Date</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php foreach($uploads as $file): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($file['name']); ?></td>
                            <td><code><?php echo strtoupper($file['type']); ?></code></td>
                            <td><?php echo number_format($file['size'] / 1024, 1); ?> KB</td>
                            <td><?php echo $file['date']; ?></td>
                            <td><a href="uploads/<?php echo urlencode($file['name']); ?>" target="_blank" class="btn-link">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($uploads)): ?>
                        <tr><td colspan="5" style="text-align:center;color:#999;">No files uploaded yet</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <?php include 'includes/footer.php'; ?>
    <script>
    // CLIENT-SIDE ONLY validation (easily bypassed via Burp)
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        var file = document.getElementById('fileInput').files[0];
        if (file) {
            var ext = file.name.split('.').pop().toLowerCase();
            var allowed = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'png'];
            if (!allowed.includes(ext)) {
                e.preventDefault();
                alert('File type not allowed. Accepted: ' + allowed.join(', '));
            }
        }
    });
    </script>
</body>
</html>
<?php $db->close(); ?>
